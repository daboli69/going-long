@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python install_nba_ensemble.py %*
) else (
  py -3 install_nba_ensemble.py %*
)
set "NBA_SYNC_EXIT=%ERRORLEVEL%"
if not "%NBA_SYNC_EXIT%"=="0" echo Transfer failed. Read the error above. Existing differing files were not overwritten.
pause
exit /b %NBA_SYNC_EXIT%
