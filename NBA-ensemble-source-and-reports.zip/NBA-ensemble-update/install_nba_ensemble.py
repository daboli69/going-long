"""Standard-library Windows transfer installer, also testable with temp paths.

Never overwrites a differing local model, journal, protocol or result. If any
destination file conflicts, install the complete payload in a versioned child.
"""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import uuid

DEFAULT_DESTINATION = r'C:\Users\travi\OneDrive\Documents\ChatGPT\GOING\research\NBA ensemble'


def file_hash(path):
    h=sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def safe_path(root,name):
    p=PurePosixPath(name)
    if p.is_absolute() or not p.parts or any(part in ('.','..') or ':' in part or '\\' in part for part in p.parts):
        raise ValueError('Unsafe transfer manifest path: '+name)
    result=root.joinpath(*p.parts)
    for parent in [result,*result.parents]:
        if parent==root.parent:
            break
        if parent.is_symlink():
            raise ValueError('Symlink in transfer path: '+str(parent))
    return result


def read_payload(payload):
    payload=Path(payload).resolve()
    manifest_path=payload/'BUNDLE_CONTENTS.json'
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    if manifest.get('kind')!='nba_ensemble_portable_snapshot':
        raise ValueError('Unknown transfer manifest')
    paths=set()
    for record in manifest['files']:
        name=record['path']
        if name in paths:
            raise ValueError('Duplicate manifest path')
        paths.add(name)
        path=safe_path(payload,name)
        if not path.is_file() or file_hash(path)!=record['sha256'] or path.stat().st_size!=record['bytes']:
            raise ValueError('Source file failed verification: '+name)
    return manifest,file_hash(manifest_path)


def install(payload,destination,verify_only=False):
    payload=Path(payload).resolve()
    destination=Path(destination).resolve()
    manifest,manifest_hash=read_payload(payload)
    records=manifest['files']+[dict(path='BUNDLE_CONTENTS.json',sha256=manifest_hash,bytes=(payload/'BUNDLE_CONTENTS.json').stat().st_size)]
    conflicts=[]
    for record in records:
        path=safe_path(destination,record['path'])
        if path.exists() and (not path.is_file() or file_hash(path)!=record['sha256']):
            conflicts.append(record['path'])
    if verify_only:
        missing=[record['path'] for record in records if not safe_path(destination,record['path']).is_file()]
        return dict(status='verified' if not conflicts and not missing else 'not_current',
                    root=str(destination),conflicts=conflicts,missing=missing,manifest_sha256=manifest_hash)
    version='2026-10-27-'+manifest_hash[:12]
    install_root=destination/'updates'/version if conflicts else destination
    install_root.mkdir(parents=True,exist_ok=True)
    lock=install_root/'.nba-transfer.lock'
    with lock.open('x',encoding='utf-8') as out:
        out.write(str(os.getpid()))
    copied=0
    try:
        # Preflight the chosen version too; frozen imports are never overwritten.
        for record in records:
            target=safe_path(install_root,record['path'])
            if target.exists() and (not target.is_file() or file_hash(target)!=record['sha256']):
                raise ValueError('Versioned destination also conflicts: '+str(target))
        for record in records:
            source=safe_path(payload,record['path'])
            target=safe_path(install_root,record['path'])
            if target.exists():
                continue
            target.parent.mkdir(parents=True,exist_ok=True)
            temporary=target.with_name(target.name+'.incoming-'+uuid.uuid4().hex)
            try:
                shutil.copyfile(source,temporary)
                if file_hash(temporary)!=record['sha256']:
                    raise ValueError('Staged copy failed verification: '+record['path'])
                if target.exists():
                    if not target.is_file() or file_hash(target)!=record['sha256']:
                        raise ValueError('Destination changed during transfer: '+str(target))
                else:
                    # Exclusive creation prevents overwriting a concurrent local edit.
                    with target.open('xb') as writer,temporary.open('rb') as reader:
                        shutil.copyfileobj(reader,writer)
                    copied+=1
            finally:
                temporary.unlink(missing_ok=True)
        for record in records:
            if file_hash(safe_path(install_root,record['path']))!=record['sha256']:
                raise ValueError('Installed hash mismatch: '+record['path'])
        receipt=dict(status='verified_versioned_install' if conflicts else 'verified',
                     requested_destination=str(destination),installed_root=str(install_root),
                     files_verified=len(records),files_copied=copied,manifest_sha256=manifest_hash,
                     existing_conflicts_preserved=conflicts,recorded_at=datetime.now(timezone.utc).isoformat(),
                     windows_file_copy_verified=os.name=='nt',existing_app_integration_verified=False,
                     onedrive_cloud_sync_verified=False)
        receipts=destination/'transfer-receipts'
        receipts.mkdir(parents=True,exist_ok=True)
        path=receipts/('nba-update-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]+'.json')
        with path.open('x',encoding='utf-8') as out:
            json.dump(receipt,out,indent=2)
        receipt['receipt_path']=str(path)
        return receipt
    finally:
        lock.unlink(missing_ok=True)


def main():
    parser=argparse.ArgumentParser(description='Verify and install all NBA research updates without overwriting local work')
    parser.add_argument('--payload',default=str(Path(__file__).resolve().parent/'payload'))
    parser.add_argument('--destination')
    parser.add_argument('--verify-only',action='store_true')
    args=parser.parse_args()
    if args.destination is None and os.name!='nt':
        parser.error('The Windows C: drive is not available here; use an explicit test destination on this platform')
    result=install(args.payload,args.destination or DEFAULT_DESTINATION,args.verify_only)
    print(json.dumps(result,indent=2))
    if result['status']=='not_current':
        sys.exit(2)


if __name__=='__main__':
    main()
