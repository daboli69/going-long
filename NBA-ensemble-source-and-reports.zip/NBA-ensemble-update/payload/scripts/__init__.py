"""Portable NBA research modules."""
