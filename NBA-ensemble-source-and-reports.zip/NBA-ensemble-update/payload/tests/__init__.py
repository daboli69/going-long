"""Portable NBA research checks."""
