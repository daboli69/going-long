"""Portable reference namespace; original model implementations are unchanged."""
