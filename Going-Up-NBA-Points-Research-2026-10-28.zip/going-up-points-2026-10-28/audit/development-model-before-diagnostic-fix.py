"""One generative candidate. No targets, prices, injury guesses or external projections."""
from collections import defaultdict
from datetime import timedelta
import math
import numpy as np

from .io import utc

KEYS = ('minutes','pts','reb','ast','fgm','fga','tpm','tpa','ftm','fta','oreb','dreb')


def weights(rows, origin, season, half_life, season_decay=.65):
    if not rows:
        return np.empty(0)
    anchors = {}
    stamps = [utc(r['tipoff']) for r in rows]
    for r, t in zip(rows, stamps):
        if season-3 <= r['season'] <= season and t < origin:
            anchors[r['season']] = max(anchors.get(r['season'], t), t)
    anchors[season] = origin
    return np.array([season_decay**(season-r['season'])*2**(-max(0,(anchors[r['season']]-t).total_seconds()/86400)/half_life)
                     if season-3 <= r['season'] <= season and t < origin else 0. for r,t in zip(rows, stamps)])


def summary(rows, w):
    total = float(w.sum())
    return dict(rows=len(rows), effective_sample_size=float(total**2/np.dot(w,w)) if total else 0.,
                season_contributions={str(s):float(sum(v for r,v in zip(rows,w) if r['season']==s)/total) for s in sorted({r['season'] for r in rows})} if total else {})


def groups(history):
    players, positions = defaultdict(list), defaultdict(list)
    for g in history:
        for p in g['players']:
            r = dict(p, season=g['season'], tipoff=g['tipoff'])
            players[p['player_id']].append(r)
            positions[p['position']].append(r)
    return players, positions


def context(slate, history, parameters):
    origin, season = utc(slate['origin']), slate['season']
    own, by_position = groups(history)
    by_position['__LEAGUE__'] = [r for rows in own.values() for r in rows]
    bases = {}
    for position, rows in by_position.items():
        w = weights(rows, origin, season, parameters['half_life'])
        a = np.array([[p[k] for k in KEYS] for p in rows], dtype=float)
        mean = a.T@w/w.sum()
        positive = np.array([p['minutes']>0 for p in rows])
        bases[position] = dict(values=dict(zip(KEYS,mean)), rows=rows, weights=w,
                               pplay=float(w@positive/w.sum()), positive_minutes=a[positive,0],
                               positive_weights=w[positive]/w[positive].sum())
    result = []
    for p in slate['players']:
        rows = own.get(p['player_id'], [])
        w = weights(rows, origin, season, parameters['half_life'])
        base = bases.get(p['position']) or bases['__LEAGUE__']
        raw = {k:sum(r[k]*v for r,v in zip(rows,w)) for k in KEYS}
        role = [r for r in rows if r['team']==p['team'] and r['season']==season]
        rw = weights(role, origin, season, parameters['half_life'])
        positive = [(r['minutes'],v) for r,v in zip(role,rw) if r['minutes']>0]
        k = parameters['prior_games']
        stats = {key:raw[key]+k*base['values'][key] for key in KEYS}
        pp = (sum(v for r,v in zip(role,rw) if r['minutes']>0)+k*base['pplay'])/(rw.sum()+k)
        result.append(dict(**p, own=rows, own_weights=w, role=role, role_weights=rw,
                           base=base, raw=raw, stats=stats, pplay=pp, positive=positive,
                           evidence=summary(rows,w), role_evidence=summary(role,rw),
                           prior_rate_share=float(k*base['values']['minutes']/stats['minutes']),
                           experience='unknown_no_verified_debut'))
    return result


def cap_minutes(raw, lengths):
    x = np.asarray(raw, dtype=float).copy()
    lengths = np.asarray(lengths, dtype=float)
    if np.any((x>0).sum(axis=1)<5):
        raise ValueError('Fewer than five positive roles')
    fixed = np.zeros_like(x, dtype=bool)
    for _ in range(x.shape[1]+1):
        free = np.where(fixed,0,x)
        need = 5*lengths-(fixed*lengths[:,None]).sum(axis=1)
        scale = np.divide(need,free.sum(axis=1),out=np.zeros(len(x)),where=free.sum(axis=1)>0)
        x = np.where(fixed,lengths[:,None],free*scale[:,None])
        new = x>lengths[:,None]+1e-10
        if not new.any():
            if not np.allclose(x.sum(axis=1),5*lengths,atol=1e-8):
                raise AssertionError('Minute accounting')
            return x
        fixed |= new
    raise AssertionError('Minute normalization failed')


def allocate(total, rates, rng):
    total = np.asarray(total,dtype=np.int64)
    rates = np.asarray(rates,dtype=float)
    if rates.ndim==1:
        rates = np.broadcast_to(rates,(len(total),len(rates)))
    if np.any(rates<0) or np.any((rates.sum(axis=1)<=0)&(total>0)):
        raise ValueError('Unsupported opportunity pool')
    out=np.zeros(rates.shape,dtype=np.int64)
    left,remaining=total.copy(),rates.sum(axis=1)
    for j in range(rates.shape[1]):
        prob=np.divide(rates[:,j],remaining,out=np.zeros(len(total)),where=remaining>1e-12)
        out[:,j]=rng.binomial(left,np.clip(prob,0,1))
        left-=out[:,j]
        remaining=np.maximum(0,remaining-rates[:,j])
    if left.any():
        raise AssertionError('Unallocated attempts')
    return out


def baseline(profiles, origin, season):
    """Fixed 90-day/.65 prior-outcomes baseline, five position pseudo-games."""
    result=[];cache={}
    for p in profiles:
        rows=p['own'];w=weights(rows,origin,season,90)
        base=p['base']
        key=id(base)
        if key not in cache:
            bw=weights(base['rows'],origin,season,90)
            bp=np.bincount([r['pts'] for r in base['rows']],weights=5*bw/bw.sum())
            cache[key]=bp
        bp=cache[key]
        size=max(len(bp),1+max([r['pts'] for r in rows],default=0))
        pmf=np.pad(bp,(0,size-len(bp)))
        for r,v in zip(rows,w):pmf[r['pts']]+=v
        result.append(pmf/pmf.sum())
    return result


def simulate(slate, profiles, templates, parameters, draws, seed, ablation=None, observed=None):
    rng=np.random.default_rng(seed)
    origin=utc(slate['origin'])
    pool=[g for g in templates if slate['season']-3<=g['season']<=slate['season'] and utc(g['tipoff'])+timedelta(hours=parameters.get('lag_hours',36))<origin]
    if len(pool)<20:raise ValueError('insufficient_reconciled_earlier_templates')
    w=weights(pool,origin,slate['season'],parameters['half_life']);w/=w.sum()
    choices=rng.choice(len(pool),size=draws,p=w)
    lengths=np.array([pool[i]['length'] for i in choices],dtype=float)
    result={k:np.zeros((draws,len(profiles)),dtype=np.int64) for k in ('points','fga','fta','two_made','three_made','ft_made')}
    result['minutes']=np.zeros((draws,len(profiles)))
    diagnostics=[]
    for side,team in (('home',slate['home']),('away',slate['away'])):
        slots=[j for j,p in enumerate(profiles) if p['team']==team]
        selected=[profiles[j] for j in slots]
        active=rng.random((draws,len(slots)))<np.array([p['pplay'] for p in selected])
        initial_reject=int(np.sum(active.sum(axis=1)<5))
        for _ in range(100):
            bad=active.sum(axis=1)<5
            if not bad.any():break
            active[bad]=rng.random((bad.sum(),len(slots)))<np.array([p['pplay'] for p in selected])
        if np.any(active.sum(axis=1)<5):raise ValueError('participation_conditioning_failed')
        raw=np.zeros(active.shape)
        for j,p in enumerate(selected):
            prior=parameters['prior_games']/(p['role_weights'].sum()+parameters['prior_games'])
            base=rng.choice(p['base']['positive_minutes'],draws,p=p['base']['positive_weights'])
            if p['positive']:
                values,ww=map(np.array,zip(*p['positive']))
                own=rng.choice(values,draws,p=ww/ww.sum())
                raw[:,j]=np.where(rng.random(draws)<prior,base,own)
            else:raw[:,j]=base
        minutes=cap_minutes(raw*active,lengths)
        if ablation=='observed_minutes':
            m=np.array([observed[j]['minutes'] for j in slots])
            actual_length=m.sum()/5
            if abs(actual_length-slate['observed_game_length'])>.05:raise ValueError('oracle_field_does_not_cover_minutes')
            lengths=np.full(draws,actual_length)
            minutes=np.broadcast_to(m,(draws,len(m))).copy()
        result['minutes'][:,slots]=minutes
        fga=np.array([pool[i][side]['fga'] for i in choices])
        fta=np.array([pool[i][side]['fta'] for i in choices])
        if ablation=='fixed_pace':
            pace=np.array([.5*(pool[i]['home']['possession_proxy']+pool[i]['away']['possession_proxy'])*48/pool[i]['length'] for i in choices])
            fixed=sum(v*.5*(g['home']['possession_proxy']+g['away']['possession_proxy'])*48/g['length'] for g,v in zip(pool,w))
            def rounding(x):
                return np.floor(x).astype(np.int64)+(rng.random(draws)<x%1)
            fga=rounding(fga*fixed/pace);fta=rounding(fta*fixed/pace)
        if ablation=='observed_team_pools':
            fga=np.full(draws,sum(observed[j]['fga'] for j in slots))
            fta=np.full(draws,sum(observed[j]['fta'] for j in slots))
        player_attempts={}
        stats=[]
        for p in selected:
            k=parameters['prior_games']
            if ablation=='no_pooling' and p['own_weights'].sum()>=10:k=0
            if ablation=='strong_pooling':k=30
            stats.append({key:p['raw'][key]+k*p['base']['values'][key] for key in KEYS})
        for kind,total in (('fga',fga),('fta',fta)):
            rr=[]
            for p,s in zip(selected,stats):
                shape=max(1e-6,s[kind])
                rate=shape/max(1,s['minutes'])
                rr.append(np.full(draws,rate) if ablation=='simple_opportunity' else rng.gamma(shape,1/max(1,s['minutes']),draws))
            rr=np.array(rr).T*minutes
            bad=rr.sum(axis=1)<=0;rr[bad]=minutes[bad]
            player_attempts[kind]=allocate(total,rr,rng)
        if ablation=='observed_individual_attempts':
            player_attempts={k:np.broadcast_to([observed[j][k] for j in slots],(draws,len(slots))).copy() for k in ('fga','fta')}
        for j,(slot,p,s) in enumerate(zip(slots,selected,stats)):
            def probability(success,total):
                a,b=1+max(0,success),1+max(0,total-success)
                return np.full(draws,a/(a+b)) if ablation=='fixed_conversion' else rng.beta(a,b,draws)
            attempts=player_attempts['fga'][:,j]
            threes=rng.binomial(attempts,probability(s['tpa'],s['fga']))
            twos=attempts-threes
            m2=rng.binomial(twos,probability(s['fgm']-s['tpm'],s['fga']-s['tpa']))
            m3=rng.binomial(threes,probability(s['tpm'],s['tpa']))
            mft=rng.binomial(player_attempts['fta'][:,j],probability(s['ftm'],s['fta']))
            result['points'][:,slot]=2*m2+3*m3+mft
            result['fga'][:,slot]=attempts;result['fta'][:,slot]=player_attempts['fta'][:,j]
            result['two_made'][:,slot]=m2;result['three_made'][:,slot]=m3;result['ft_made'][:,slot]=mft
        diagnostics.append(dict(team=team,templates=len(pool),template_ESS=float(1/(w@w)),
             rejection_fraction=initial_reject/draws, minute_accounting_max_error=float(np.max(abs(minutes.sum(axis=1)-5*lengths))),
             marginal_play_before=[float(p['pplay']) for p in selected],marginal_play_after=(minutes>0).mean(axis=0).tolist(),
             fga_total_mean=float(result['fga'][:,slots].sum(axis=1).mean()),fta_total_mean=float(result['fta'][:,slots].sum(axis=1).mean())))
    result['diagnostics']=diagnostics
    return result
