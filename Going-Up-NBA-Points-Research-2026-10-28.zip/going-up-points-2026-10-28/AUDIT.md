# Going Up: audit before implementation

2026-10-28. Checkout: `8d8b7a14030960674eef8e4f40da07ffb1d6e8f3`.

## Findings reported before changes

1. **Critical evidence gap:** the Windows `app.py`, `nba_lab` and original local player-points forecasts are unavailable. No claim about improvement over that application can be established here. The accessible winner module predicts game winners, not player points.
2. **High:** KOTC v1 already is an opportunity-based generative model. `scripts/king_court/simulation.py:74` onward draws shared pace, positive minutes, Poisson team FGA/FTA, minute/rate-weighted opportunities, Beta conversion and integer points. Its distributions are research-only. Rebuilding the same idea does not establish novelty or superiority.
3. **High:** real KOTC distribution diagnostics used postgame box fields, unknown experience priors and reused archives (`scripts/king_court_diagnostics/dataset.py`). Those are conditional diagnostics, not immutable pregame forecasts. The saved synthetic NPZ receipts are not real NBA predictions.
4. **High:** positive lognormal minutes normalized to team totals have no available-player DNP mixture; conditional opportunity variance, role allocation, weak Beta exposures and opponent logit adjustments remain assumptions. Historical injury records are missing. Neither eventual participation nor an `active` box flag is a historical injury input.
5. **High:** no untouched historical season can honestly be asserted. The four-season boxes and full ending-year-2026 event archive were previously read for reconciliation. New chronological replay will be explicitly reused-data research. Future confirmation remains unopened and empty.
6. **No market input found in accessible NBA path:** direct source/feature inspection shows basketball schedules, boxes, events and explicit allowlisted quantities. Prize/ownership functions are separate and will not be imported by the new candidate. The unseen local model cannot be certified market-free. Unrelated football/odds systems are outside this audit and will not be executed.
7. Native vendor event JSON, independently observed period-start lineups, verified debut metadata and timestamped pregame injuries are absent. Parsed NBA actions and inferred lineup snapshots are the least-processed accessible retained records. Their provider overlap must remain explicit.

## Bounded response

Preserve every existing file. Add one isolated study, not a production change. Build one points-only generative candidate and compare it with a prior-outcomes empirical baseline. A frozen-code KOTC reconstruction is an auxiliary comparator, not the unseen local model or an original historical forecast. Generate player fields from earlier team boxes, not target-game participants. Explicitly label this a roster proxy, count absent/unknown outcomes, and do not impute them as DNP zeros.

Reconcile shot/point event credits independently against NBA boxes, rerun existing event/stint audit, independently recalculate prior reported metrics and rerun preserved tests. Register design before new development/final comparison. Unavailable historical injuries remain excluded. Strict point-in-time receipt enforcement will be reported even if it yields no eligible observations.

The overall user question requires genuine original-model forecasts and later point-in-time evidence. A useful conditional retrospective comparison cannot fill those missing requirements.
