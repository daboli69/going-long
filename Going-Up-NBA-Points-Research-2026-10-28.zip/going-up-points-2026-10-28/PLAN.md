# Going Up: fixed research plan

Registered before new candidate evaluation; exact time and file hashes are in registration.json. This is one study of player-points distributions, not an interface, market, or replacement model.

## Hypothesis and decision

One basketball-only generative model improves player-points CRPS by at least **0.10 point and 2%** versus a simple empirical baseline and the existing model on matched information/observations. A supported verdict additionally requires a two-way game/player-cluster 95% upper delta below zero against both, nonworsening MAE by more than .10, 80% coverage within [.75,.85], consistent chronological direction, genuine point-in-time inputs/original comparator and an untouched confirmation sample with at least 50 games, 200 players and 2000 scored player-games. Thresholds are prespecified practical study criteria, not universal basketball constants. Missing original forecasts or reliable untouched evidence forces an **Inconclusive** overall verdict, regardless of retrospective scores. Reliable adequate evidence failing the improvement criteria supports **Not supported**, not rescue tuning.

## Cohorts, chronology and missingness

Use ending-year 2026 targets with season-to-date plus ending years 2023, 2024, 2025. Target the first scheduled regular-season game (tipoff, then game ID) on each America/New_York date. Do not pick another game if that game's outcome/reconciliation is missing.

- Development: 2025-11-01 through 2025-12-31.
- Earlier chronological stress assessment: 2026-01-01 through 2026-02-28.
- Later retrospective assessment: 2026-03-01 through 2026-04-12.
- True future confirmation reservation: 2026-11-01 through 2026-11-30. No forecasts/jobs are created for these dates. Append a new registration before outcomes if coverage is insufficient; never extend after inspecting results.

Historical archives were already inspected. All historical periods are **reused chronological assessment**, not untouched. Origins are six hours before scheduled tipoff; basketball results are embargoed 36 hours from tipoff. Sensitivity to a 72-hour embargo is development-only. The final runner must reject code/input hash changes after lock.

Player field: each team's most recent earlier current-season box available under the embargo, requiring at least five team games and ten listed players. These are prior-roster proxies, not certified availability. The target game's participant list must not generate the field. Score only exact target NBA-box records (including explicit zero-minute records); absent players remain unknown/unscorable with counts and exclusion receipts. Do not infer a missing player's zero. Report missing-outcome sensitivity and the restricted estimand. No injury, projected starter, eventual participation, unverified rookie label or market data is an input.

## Single candidate

Playing time -> jointly resampled team conditions/possession proxy -> integer FGA/FTA opportunities -> 2/3-point and free-throw conversion -> points. This is a structural hypothesis, not causal identification.

Minutes: a partial-pooled historical participation hurdle and empirical positive-minute draws, conditioned on at least five positive roles, then constrained to five times shared game length. Role uses only current-team/current-season history. Unknown experience uses an explicit position prior, never an invented NBA debut. Transferrable per-minute attempts and shooting use player history plus position pseudo-games. No injury status mixture is fabricated.

Team conditions: jointly resample an earlier, independently shot-reconciled NBA game template containing both teams' FGA, FTA, possession proxy and overtime length. The possession proxy is FGA-OREB+TOV+.44FTA, not observed exact possessions. Shared observed templates preserve empirical dependence among pace/opportunity totals. The candidate is an empirical mixture with hierarchical player allocation/conversion, not a full possession engine or identity-specific opponent model. All template support is earlier and within the rolling window. The available event archive only supports ending-year 2026 templates; disclose that narrower component support.

Allocate FGA/FTA to positive-minute players by minute x Gamma per-minute attempt rates; integer multinomials conserve team totals. Beta partial pooling produces three-point share and 2P/3P/FT probabilities. Makes cannot exceed attempts. Points equal 2*2PM+3*3PM+FTM. No rebounds/assists or unrelated feature families are added.

Development selection: season decay fixed .65; half-life {30,90} days and prior pseudo-games {5,15}, four configurations. Select lowest player-game mean CRPS, deterministic tie order (half-life, prior games). Selection simulations 2000; assessment 8000. Seeds 281026 and 281027. No final retuning or seed selection. Newer seasons have higher per-observation weight; report actual ESS and season contributions, not promises about total current-season mass.

A: weighted empirical prior player-points distribution, shrinking five pseudo-games to the prior position distribution, no opportunities. Uses all own prior outcomes in the rolling window; uniform-outcomes simplification is a development falsification. B: unchanged KOTC code reconstructed with the exact same prior-roster proxy, unknown-experience diagnostic adapter and selected candidate recency for comparability. This is auxiliary, not a valid original forecast comparison. C: the single candidate above. C and B are not independent systems merely because implementations differ.

## Metrics and falsification

Primary: empirical-PMF CRPS, averaged over matched scored player-games; independent calculation by the integer-CDF identity. Secondary: mean MAE, 50/80/95% coverage, >=30/>=40-point event Brier and reliability, discrete randomized PIT, zero mass, variance/residual behavior and chronological periods. Finite Monte Carlo probability logs are not reliable log scores at unseen counts; report their limitation rather than fabricate densities. No betting return metric.

Paired uncertainty: 2000 crossed game/player count-bootstrap resamples, game-only and player-only intervals, and week/player sensitivity. These are finite-sample clustered approximations, not a cure for selection or missing input records. Preserve full paired rows. Monte Carlo SE from eight independent draw batches and a second prespecified seed; report separately from input/parameter/structural uncertainty.

Development-only ablations: recorded minutes where the prior field accounts for all positive-minute outcomes; fixed pace scaling of the same joint template; recorded team attempt pools; recorded individual attempts; fixed conversion probabilities. Oracle results diagnose conditional sensitivity, are not attainable forecasts, and do not add to an identified variance decomposition. Simplified allocation, no pooling, stronger pooling, recency-grid results and 72-hour lag are development falsification only. Do not tune against stress/later outcomes. All extremes remain in scoring; report >=30 and >=40 subsets without trimming them from the main score.

Strict historical source-known-time enforcement is a falsification: the existing retrieved-in-2026 archives are not contemporary 2025/early-2026 receipts. Report zero eligible strict observations if that is what the timestamps imply. Do not relabel an assumed 36-hour availability lag as proof of historical knowledge.

## Reproduction and preservation

Before comparisons, preserve initial git status and SHA256s of original NBA code/configs/reports and input bytes. Hash all new candidate code before first assessment. Save new forecasts, distributions, outcomes, identities, cutoffs, chosen parameters, exclusion reasons, seeds, environment versions and source receipts. New outputs only; no overwrite. Independently rerun raw shot/point reconciliation and the old event/stint audit. Recalculate prior score claims from saved observations, and rerun old tests. Passing tests are software checks only.

Final report answers the user's eight questions and ends with exactly one of the requested verdicts. Claude handoff must explicitly say which new files to add, which old files to leave unchanged, how to reproduce without local app access, and what genuine future evidence would resolve the conclusion.
