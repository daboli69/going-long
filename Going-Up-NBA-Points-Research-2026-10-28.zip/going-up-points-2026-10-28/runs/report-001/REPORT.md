# Going Up: independent player-points study

This is a basketball-only, isolated research experiment. No production model was changed. Historical results below are reused chronological replays with assumed result publication lags and prior-roster proxies; they are not genuine historical pregame forecasts.

## 1. Does the candidate outperform the existing model?

That primary question cannot be resolved: the Windows player-points model and its immutable forecasts were unavailable. B below is unchanged KOTC v1 code reconstructed on the same earlier roster proxy, with an explicit unknown-experience adapter. It is an auxiliary reference, not the local production model. A is an outcomes-only empirical baseline. C is the one generative candidate.

## 2. Size and uncertainty

| Period/model | Games | Player-games | CRPS | MAE | 80% coverage |
| --- | ---: | ---: | ---: | ---: | ---: |
| stress/A | 53 | 1289 | 3.2755 | 4.8954 | 88.67% |
| stress/B_reconstruction | 53 | 1289 | 3.1500 | 4.6141 | 82.70% |
| stress/C | 53 | 1289 | 3.0885 | 4.6031 | 88.52% |
| later/A | 42 | 1033 | 3.3741 | 4.9453 | 89.06% |
| later/B_reconstruction | 42 | 1033 | 3.2770 | 4.7468 | 83.16% |
| later/C | 42 | 1033 | 3.2328 | 4.7498 | 88.09% |

C-minus-reference CRPS and approximate paired game/player-cluster 95% intervals:

- stress, A: -0.1870, interval [-0.3179, -0.0628], relative reduction 5.71%.
- stress, B_reconstruction: -0.0614, interval [-0.0969, -0.0276], relative reduction 1.95%.
- later, A: -0.1413, interval [-0.3047, +0.0332], relative reduction 4.19%.
- later, B_reconstruction: -0.0442, interval [-0.0879, -0.0044], relative reduction 1.35%.

These intervals account for crossed observed game/player clusters approximately. Week/player sensitivity, game-only/player-only intervals, missing-outcome bounds, both simulation seeds and full paired rows are retained in the assessment artifacts. They do not correct missing source publication evidence or roster selection.

## 3. Which scoring components explain errors?

The study does not identify additive causal error shares. Development-only oracle and removal tests measure conditional sensitivity with interactions. Component diagnostics use the first 12 eligible development games; no assessment ablations or rescue tuning occurred. Two diagnostic defects were corrected before assessment while preserving original receipts and proving actual candidate samples unchanged: player-ID alignment under the 72-hour lag, and recorded-minute conditioning for the nested individual-attempt oracle.

- C: minutes CRPS 3.693, minutes MAE 5.793, nonparticipation Brier 0.0865; points/minutes residual correlation 0.637.
- B_reconstruction: minutes CRPS 4.110, minutes MAE 5.963, nonparticipation Brier 0.1310; points/minutes residual correlation 0.634.
- Development observed_minutes: CRPS change -0.8690 on 26 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development fixed_pace: CRPS change +0.0016 on 290 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development observed_team_pools: CRPS change +0.0425 on 26 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development observed_individual_attempts: CRPS change -1.8510 on 26 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development fixed_conversion: CRPS change +0.0036 on 290 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development simple_opportunity: CRPS change -0.0012 on 290 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development no_pooling: CRPS change -0.0315 on 290 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development strong_pooling: CRPS change +0.1288 on 290 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.
- Development lag72: CRPS change +0.0906 on 26 matched player-games. Recorded-outcome variants are oracles, not attainable predictions.

## 4. Reducible versus unpredictable uncertainty

Reliable pregame participation, current role, roster membership and historical data versions are potentially reducible input uncertainties. Shot conversion, possession variation and actual rotation choices retain stochastic variation. The available data cannot identify a numerical irreducible-error floor. More draws only reduce Monte Carlo error.

## 5. Generalization across time

The two later historical periods are evaluated once after development selection, but their source archives were already inspected in earlier research. Direction, magnitude, calibration and extremes must be read across both; neither is an untouched confirmation set. Strict contemporaneous-source enforcement yielded 0 eligible historical forecasts.

## 6. Falsification and predictive checks

All extreme outcomes remain in primary scores. >=30/>=40 event reliability and loss, discrete PIT, interval coverage, residuals, finite-support log-score failures, a second simulation seed, crossed-cluster and week-cluster intervals are retained. Development tests simplify opportunities, remove/increase pooling, remove latent conversion variation and impose a 72-hour result embargo. Cohort changes in that lag test are excluded from paired comparisons and logged. Historical injury inputs are entirely excluded.

The candidate must clear at least .10 point and 2% CRPS improvement, a clustered upper interval below zero against A and a valid B, calibration/MAE gates and untouched point-in-time evidence. Retrospective numerical superiority alone cannot clear those criteria.

## 7. Independent evidence and reproduction

All 1,230 ending-year-2026 regular-season games reconciled point, FGA/FGM, 3PA/3PM and FTA/FTM credits against NBA boxes in the independent shot parser. 1,182 joint templates also met the exact-team-minute requirements. Original event/stint checks were independently rerun; native vendor JSON and independent lineup seeds remain absent. Scoring uses the CDF identity and is independently recomputed from saved forecast PMFs through the energy identity. Code/input versions, deterministic ordering, seeds, code lock, forecasts, outcomes, exclusions and source hashes are retained.

Log scores are not rescued with arbitrary floors: finite Monte Carlo/empirical support can assign zero mass to observed counts, so a reliable full log-score comparison is unavailable. This limitation remains explicit.

## 8. Is further forward testing justified?

The artifacts are suitable for a preregistered research-only forward comparison if complete actual-time rosters, source receipts and immutable local-model forecasts can be obtained. This is not evidence to replace a model. The future reservation was extended before future outcomes to November 1, 2026–February 28, 2027 because the original month could not meet the sample minimum. No future forecasts, outcomes, scheduler or deployment were created.

![Diagnostics](diagnostics.png)

Inconclusive: insufficient reliable evidence
