"""Build one immutable source/derived-data/forecast handoff, excluding raw caches."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
a=p.parse_args()
if a.output.exists():raise FileExistsError(a.output)
files=[]
for f in sorted(root.rglob('*')):
    if not f.is_file() or any(n in f.parts for n in ('__pycache__','.pytest_cache','.venv','.venv-research','.git')):continue
    if f.name=='PACKAGE_MANIFEST.json' or f.suffix=='.zip':continue
    files.append(f)
records=[dict(path=f.relative_to(root).as_posix(),bytes=f.stat().st_size,sha256=sha256(f.read_bytes()).hexdigest()) for f in files]
manifest=root/'PACKAGE_MANIFEST.json'
with manifest.open('x',encoding='utf-8') as stream:
    json.dump(dict(kind='going_up_points_research_handoff',created_at=datetime.now(timezone.utc).isoformat(),
        files=records,raw_vendor_caches_included=False,derived_input_snapshot_included=True,
        original_PC_app_included=False,production_integration_verified=False,
        verdict='Inconclusive: insufficient reliable evidence'),stream,indent=2)
with ZipFile(a.output,'x',compression=ZIP_DEFLATED,compresslevel=9) as out:
    for f in files+[manifest]:out.write(f,arcname=root.name+'/'+f.relative_to(root).as_posix())
with ZipFile(a.output) as z:
    if z.testzip() is not None:raise ValueError('Archive CRC failed')
meta=dict(path=str(a.output.resolve()),bytes=a.output.stat().st_size,sha256=sha256(a.output.read_bytes()).hexdigest(),
          payload_files=len(files)+1,manifest_sha256=sha256(manifest.read_bytes()).hexdigest())
print(json.dumps(meta,indent=2))
