# Frozen candidate and comparison interpretation

## Forecast identity and target

Target: nonnegative integer total player points, including overtime, for the first regular-season game on each Eastern date. A player is forecast because they were listed in their team's latest earlier box under a 36-hour result embargo. This is a continuing/prior-roster proxy population, not all NBA players or a verified injury-cleared roster. Unknown current outcomes remain unscored and bounded, never zero-imputed. New joiners/debutants absent from the proxy are outside this estimand.

Historical target season is ending-year 2026. Training at each origin uses its season-to-date plus ending years 2023–2025; ending-year 2027 rows carried in the input archive never enter those predictions. Future ending-year 2027 work must roll to 2024–2027.

## Weighting

For an eligible observation in season s, target season S, within-season age d:

    w = .65**(S-s) * 2**(-d / half_life)

The target season anchors at origin; prior seasons anchor at their latest eligible observation within each relevant history. Effective sample size is (sum w)^2/sum(w^2). Newer seasons get higher per-observation season weight, not a guarantee of greatest total mass. This is a power-weighted empirical-Bayes approximation. No verified debut labels were available; positions provide explicitly unknown-experience priors. No rookie/second-year validation is claimed.

Half-life and prior pseudo-games are selected from four configurations on development only. There is no assessment retuning. Per-player evidence and season shares are stored in every forecast receipt. Hyperparameter uncertainty is not a fully integrated posterior; grid sensitivity and development ablations are disclosed.

## Playing time

Current-team/current-season records supply participation and positive-minute evidence. Position cohorts provide pseudo-game support. The predictive participation probability is the weighted observed-positive fraction partially pooled to the position fraction. Explicit historical DNP rows are legitimate zeros; missing observations are not.

Draw initial player participation states, reject team states with fewer than five positive roles, then draw positive minutes from the weighted role/position empirical mixture. Normalize and cap minutes to 5 times shared game length, with each individual at most game length. Rejection and normalization induce dependence and change marginal probabilities, so both input and realized participation probabilities are retained. This is not a fitted lineup/substitution, foul-trouble or injury model.

## Team conditions and offensive opportunities

Joint template support comprises 1,182 earlier mapped games with event-to-NBA-box shooting/point agreement and the specified team-minute gate. At each origin at least 20 eligible templates are required. The available template component has ending-year 2026 support only; transferable player estimates still use the rolling four-season window.

Draw one recency-weighted earlier joint home/away template, retaining its overtime length, FGA, FTA and box possession proxy together. Factorization can be read as a discrete empirical mixture over shared possession/length conditions and conditional FGA/FTA rates. It is not a learned causal possession model, independently counted possession engine, matchup-specific opponent adjustment or new event simulator.

Possession proxy per team:

    FGA - offensive rebounds + turnovers + .44 * FTA

Producer-counted possession groups are separately observed as derived evidence, not independent truth. Template resampling preserves observed joint attempt/pace/length combinations and has finite empirical support. Unseen game extremes, and-one sequences and identity-specific opponent interactions are not established.

## Player allocation and conversion

Weighted player attempts/makes are pooled with position pseudo-game counts. Transferrable rates use all eligible player history; current-team role determines minutes. Per-minute FGA/FTA rates use Gamma uncertainty based on weighted counts and minute exposure. Multinomial allocations compete for the joint team's integer attempt totals. Zero-minute players receive no attempts in the actual candidate.

Three-point share and 2P/3P/FT conversion use Beta distributions with weighted successes/failures, pooled counts and a weak +1/+1 numerical prior. These distributions propagate rate uncertainty conditional on the estimates; they do not capture every efficiency interaction or parameter uncertainty. Made baskets cannot exceed attempts and:

    points = 2*two_point_makes + 3*three_point_makes + free_throw_makes

No sportsbook lines, odds, implied probabilities, consensus projections, markets, future availability or tracking proxies are used. The new model does not generate rebounds/assists or promotion recommendations.

## References A and B

A: .65 season decay, 90-day half-life, all eligible prior own player-points outcomes plus five position-distribution pseudo-games. Its PMF is empirical and finite; it has no minutes/opportunity mechanism. A development-only equal-weight own-outcomes baseline removes that complexity.

B: exactly preserved KOTC source with the same prior-roster proxy and selected candidate recency/prior settings. Unknown experience uses the preserved diagnostic adapter. This is a common-input reconstruction, not an immutable original forecast, a production-ready selection, or the Windows application's player-points model. Its minutes, positive lognormal assumptions, Poisson pools, matchup blending and conversions are unchanged.

## Evidence limits

Simulated game/rate dispersion, finite Monte Carlo error, unknown input status, shrinkage/parameter uncertainty and structural error are distinct. Retrospective cluster intervals are conditional on the observed cohort and input archive. Historical source-known-time enforcement yields no eligible point-in-time forecasts. Native vendor JSON, original local forecasts, genuine historical injuries, verified NBA debut metadata and untouched historical sources remain absent.

Oracle and removal ablations are development diagnostics, not causal error decompositions or achievable forecast gains. Frozen source versions and original failed/recovered reproduction attempts are retained. No production integration or model promotion is implied by this specification.
