# Going Up: independent NBA player-points research

Read [REPORT.md](REPORT.md) for findings and [CLAUDE_HANDOFF.md](CLAUDE_HANDOFF.md) for local continuation. This is an isolated research study, not a production update or an app installer.

The study compares an outcomes-only baseline, a labeled frozen-code KOTC reconstruction and one generative candidate. It uses no sportsbook inputs. Real local-model forecasts, contemporaneous historical availability and an untouched historical confirmation sample were unavailable. Numerical retrospective results must be interpreted within those limitations.

## Verify and reproduce

Extract into a separate study folder. Do not overwrite the existing NBA app or earlier versioned install. With Python 3.12:

~~~text
python verify_bundle.py
python -m venv .venv-research
# Use the new environment's Python for the following commands.
python -m pip install -r environment-lock.txt
python -m pytest -q tests
python -m going_up.reproduce --forecasts runs/assessment-001/later-forecasts.json.gz --scores runs/assessment-001/later-scores.json.gz --output score-verification-002.json
python -m going_up.run assess --development runs/development-001/development.json --output runs/reproduction-002
~~~

Set OPENBLAS_NUM_THREADS=1 and OMP_NUM_THREADS=1 for the reproduction process. On Windows invoke the isolated environment's python.exe directly; activation is optional. Every output must use a fresh path. The code lock rejects altered code, dataset, selected development receipt or frozen study definitions. The default reference folder contains the exact old comparator source and a manifest; it does not contain the original raw caches.

The portable derived dataset and forecast PMFs permit independent primary scoring and simulation reproduction. Original raw NBA/ESPN data URLs and SHA256s are retained, but raw .cache folders and native vendor JSON are not represented as delivered. Rebuilding original raw reconciliation requires exact source bytes; changed upstream archives require new receipts.

The original development ablations are preserved, with documented diagnostic corrections in runs/diagnostics-003/corrections.json. The actual candidate samples and selected parameters were unchanged by those corrections. No future predictions, jobs, promotion, interface, deployment or changes to the original NBA models were made.
