"""Preserve and correct two development-only diagnostic defects, not the candidate."""
import argparse
from datetime import datetime,timezone
import importlib.util
from pathlib import Path
import numpy as np
from .data import field,outcomes,targets
from .io import file_hash,read,write,write_gzip
from .metrics import aggregate,paired,pmf_of,row
from .model import context,simulate
from .run import PERIODS,ROOT


def run(data,development,out):
    d=read(development);chosen=d['chosen'];base=read(development.parent/'development-scores.json.gz')['C']
    ids={f['game_id'] for f in read(development.parent/'development-forecasts.json.gz')[:12]}
    results={k:[] for k in d['ablation']};notes=[];unchanged=False
    spec=importlib.util.spec_from_file_location('going_up.before_diagnostic_fix',ROOT/'audit/development-model-before-diagnostic-fix.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    for number,t in enumerate(targets(data,*PERIODS['development'])):
        if t['game_id'] not in ids:continue
        s,h=field(data,t);pp=context(s,h,chosen);actual,missing=outcomes(data,s)
        if not unchanged:
            a=old.simulate(s,pp,data['templates'],chosen,2000,281026+number*1009)
            b=simulate(s,pp,data['templates'],chosen,2000,281026+number*1009)
            for k in ('points','minutes','fga','fta','two_made','three_made','ft_made'):
                if not np.array_equal(a[k],b[k]):raise AssertionError('Candidate changed')
            unchanged=True
        official=data['official'][s['game_id']];length=sum(q['minutes'] or 0 for q in official.values())/10
        oracle=not missing and abs(sum(q['minutes'] for q in actual)/10-length)<.05
        for name in results:
            if name.startswith('observed_') and not oracle:
                notes.append(dict(game_id=s['game_id'],ablation=name,reason='incomplete_oracle_field'));continue
            par=dict(chosen);sp=dict(s,observed_game_length=length);pr=pp
            if name=='lag72':
                par['lag_hours']=72
                try:sp,hp=field(data,t,lag=72)
                except ValueError as error:
                    notes.append(dict(game_id=s['game_id'],ablation=name,reason=str(error)));continue
                pr=context(sp,hp,par)
                if {p['player_id'] for p in pr}!={p['player_id'] for p in pp}:
                    notes.append(dict(game_id=s['game_id'],ablation=name,reason='changed_proxy_membership_not_paired'));continue
                lookup={p['player_id']:p for p in pr};pr=[lookup[p['player_id']] for p in pp]
            z=simulate(sp,pr,data['templates'],par,2000,281026+number*1009,None if name=='lag72' else name,actual)
            if name=='observed_individual_attempts' and np.any(z['fga'][z['minutes']==0]):raise AssertionError('Oracle violates playing-time support')
            for j,p in enumerate(pp):
                if actual[j] is not None:results[name].append(row(pmf_of(z['points'][:,j]),actual[j],s['game_id'],p['player_id'],s['date']))
    comparisons={}
    for name,rr in results.items():
        keep={(r['game_id'],r['player_id']) for r in rr}
        comparisons[name]=dict(scores=aggregate(rr),paired_vs_C=paired([r for r in base if (r['game_id'],r['player_id']) in keep],rr))
    write_gzip(out/'corrected-ablation-rows.json.gz',results)
    write(out/'corrections.json',dict(recorded_at=datetime.now(timezone.utc).isoformat(),assessment_started=False,
        original_receipt_preserved=str(development.resolve().relative_to(ROOT)),parameters_unchanged=chosen,
        corrections=['72h comparison aligns identical player sets by ID rather than rejecting reordered lists.',
                     'Individual-attempt oracle also conditions on recorded minutes to prevent shots by simulated zero-minute players. It is a nested oracle, not isolated causal opportunity attribution.'],
        actual_candidate_arrays_unchanged=unchanged,old_model_sha256=file_hash(ROOT/'audit/development-model-before-diagnostic-fix.py'),
        new_model_sha256=file_hash(ROOT/'going_up/model.py'),ablation=comparisons,notes=notes))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--inputs',type=Path,required=True);p.add_argument('--development',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();run(read(a.inputs),a.development,a.output)
