"""Independently rebuild shot credits; never use target participants as inputs."""
from collections import Counter, defaultdict
from datetime import timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import re
import numpy as np
import polars as pl

from .io import file_hash, read, utc, write, write_gzip

STATS = ('pts', 'reb', 'ast', 'fgm', 'fga', 'tpm', 'tpa', 'ftm', 'fta', 'oreb', 'dreb')
EASTERN = ZoneInfo('America/New_York')


def box_minutes(record):
    value = record.get('minutes')
    if value:
        match = re.fullmatch(r'(\d+):(\d+(?:\.\d+)?)', str(value))
        if not match:
            raise ValueError('Invalid official minutes')
        return int(match[1]) + float(match[2]) / 60
    # This is settlement evidence only, never an availability feature.
    if re.match(r'^(DNP|DND|NWT|INACTIVE)', str(record.get('comment', '')).upper()):
        return 0.
    return None


def shot_credits(events, boxes):
    fields = {'fga': 'field_goals_attempted', 'fgm': 'field_goals_made',
              'tpa': 'three_pointers_attempted', 'tpm': 'three_pointers_made',
              'fta': 'free_throws_attempted', 'ftm': 'free_throws_made', 'pts': 'points'}
    counts = defaultdict(Counter)
    seen, issues = {}, []
    for e in sorted(events, key=lambda r: r['order_index']):
        ident = int(e['order_index'])
        if ident in seen:
            if seen[ident] != e:
                issues.append('conflicting_order_index')
            continue
        seen[ident] = e
        pid, kind = int(e['person_id'] or 0), e['action_type']
        if kind in ('Made Shot', 'Missed Shot'):
            value = int(e['shot_value'])
            if value not in (2, 3):
                issues.append('unknown_shot_value')
                continue
            counts[pid]['fga'] += 1
            counts[pid]['tpa'] += value == 3
            if kind == 'Made Shot':
                counts[pid]['fgm'] += 1
                counts[pid]['tpm'] += value == 3
                counts[pid]['pts'] += value
        elif kind == 'Free Throw':
            counts[pid]['fta'] += 1
            if not str(e['description']).upper().startswith('MISS '):
                counts[pid]['ftm'] += 1
                counts[pid]['pts'] += 1
    known = {int(b['person_id']) for b in boxes}
    if any(pid not in known for pid in counts):
        issues.append('unmapped_shooter')
    differences = []
    for b in boxes:
        pid = int(b['person_id'])
        for k, column in fields.items():
            if counts[pid][k] != int(b[column] or 0):
                differences.append([pid, k, counts[pid][k], int(b[column] or 0)])
        if int(b['points']) != 2*(int(b['field_goals_made'])-int(b['three_pointers_made'])) + 3*int(b['three_pointers_made']) + int(b['free_throws_made']):
            issues.append('box_point_identity')
    return {'passed': not differences and not issues, 'differences': differences, 'issues': issues}


def prepare(repo, out):
    repo, out = Path(repo), Path(out)
    history_path = repo/'.cache/king-court-deepening/combined-history.json'
    history = read(history_path)
    raw = repo/'.cache/king-court-deepening/raw'
    kinds = ('nba_pbp', 'nba_boxes', 'schedule_crosswalk', 'player_crosswalk', 'nba_possessions')
    paths = {k: next(raw.glob(k+'*2026*.parquet')) for k in kinds}
    tables = {k: pl.read_parquet(p) for k, p in paths.items()}
    pbp = tables['nba_pbp'].filter(pl.col('game_id').str.starts_with('002')).partition_by('game_id', as_dict=True)
    boxes = tables['nba_boxes'].filter(pl.col('game_id').str.starts_with('002')).partition_by('game_id', as_dict=True)
    canonical = {g['game_id']: g for g in history['games']}
    links = {}
    for r in tables['schedule_crosswalk'].to_dicts():
        if r['match_confidence'] == 1 and 'espn:'+str(r['espn_game_id']) in canonical:
            links[str(r['nba_game_id'])] = 'espn:'+str(r['espn_game_id'])
    mapping = defaultdict(set)
    for r in tables['player_crosswalk'].to_dicts():
        if r['match_confidence'] == 1 and r.get('espn_athlete_id') and r.get('nba_player_id'):
            mapping['espn:'+str(r['espn_athlete_id'])].add(int(r['nba_player_id']))
    identities = {p: next(iter(ids)) for p, ids in mapping.items() if len(ids) == 1}
    audits, templates, official = {}, [], {}
    pos = tables['nba_possessions'].filter(pl.col('count_as_possession') == True)
    pos_counts = {(str(r['game_id']), int(r['offense_team_id'])): r['len'] for r in pos.group_by('game_id', 'offense_team_id').len().to_dicts()}
    for (gid,), bg in boxes.items():
        br = bg.to_dicts()
        audit = shot_credits(pbp[(gid,)].to_dicts(), br) if (gid,) in pbp else {'passed': False, 'issues': ['missing_events']}
        audits[gid] = audit
        if gid not in links:
            continue
        g = canonical[links[gid]]
        official[g['game_id']] = {}
        for b in br:
            m = box_minutes(b)
            official[g['game_id']][str(b['person_id'])] = dict(
                pts=int(b['points']), minutes=m, fga=int(b['field_goals_attempted']), fta=int(b['free_throws_attempted']),
                fgm=int(b['field_goals_made']), tpa=int(b['three_pointers_attempted']), tpm=int(b['three_pointers_made']),
                ftm=int(b['free_throws_made']), team=b['team_tricode'], explicit_outcome=m is not None)
        if not audit['passed']:
            continue
        totals, lengths = {}, []
        for side in ('home', 'away'):
            rows = [b for b in br if b['side'] == side]
            if not rows or any(box_minutes(b) is None for b in rows):
                break
            minutes = sum(box_minutes(b) for b in rows)
            length = round(minutes/5)
            if abs(minutes-5*length) > .05 or length < 48 or (length-48) % 5:
                break
            lengths.append(length)
            fga = sum(int(b['field_goals_attempted']) for b in rows)
            fta = sum(int(b['free_throws_attempted']) for b in rows)
            oreb = sum(int(b['rebounds_offensive']) for b in rows)
            tov = sum(int(b['turnovers']) for b in rows)
            totals[side] = dict(fga=fga, fta=fta, possession_proxy=fga-oreb+tov+.44*fta,
                                counted_producer_possessions=pos_counts.get((gid, int(rows[0]['team_id']))))
        if len(totals) == 2 and len(set(lengths)) == 1:
            templates.append(dict(game_id=g['game_id'], nba_game_id=gid, tipoff=g['tipoff'], season=g['season'],
                                  length=lengths[0], home=totals['home'], away=totals['away']))
    # Export only basketball allowlisted keys. No source provider odds columns are read.
    games = []
    for g in history['games']:
        q = {k: g[k] for k in ('game_id', 'season', 'tipoff', 'known_at', 'home', 'away', 'game_minutes', 'teams')}
        q['players'] = [{k: p[k] for k in ('player_id', 'name', 'team', 'minutes', 'position')+STATS} for p in g['players']]
        games.append(q)
    schedule_source = next(s for s in history['sources'] if s['kind'] == 'schedule' and s['season'] == 2026)
    columns = ['game_id', 'season', 'date', 'home_abbreviation', 'away_abbreviation', 'season_type', 'notes_headline']
    schedules = pl.read_parquet(repo/schedule_source['path'], columns=columns).to_dicts()
    aliases = {'GS':'GSW', 'SA':'SAS', 'NY':'NYK', 'NO':'NOP', 'UTAH':'UTA', 'WSH':'WAS'}
    schedule = []
    for r in schedules:
        note = str(r.get('notes_headline') or '').lower()
        home = aliases.get(r['home_abbreviation'], r['home_abbreviation'])
        away = aliases.get(r['away_abbreviation'], r['away_abbreviation'])
        if r['season_type'] != 2 or home not in {'ATL','BOS','BKN','CHA','CHI','CLE','DAL','DEN','DET','GSW','HOU','IND','LAC','LAL','MEM','MIA','MIL','MIN','NOP','NYK','OKC','ORL','PHI','PHX','POR','SAC','SAS','TOR','UTA','WAS'} or away not in {'ATL','BOS','BKN','CHA','CHI','CLE','DAL','DEN','DET','GSW','HOU','IND','LAC','LAL','MEM','MIA','MIL','MIN','NOP','NYK','OKC','ORL','PHI','PHX','POR','SAC','SAS','TOR','UTA','WAS'}:
            continue
        if 'championship' in note and ('cup' in note or 'in-season tournament' in note):
            continue
        schedule.append(dict(game_id='espn:'+str(r['game_id']), season=int(r['season']), tipoff=utc(r['date']).isoformat(), home=home, away=away))
    dataset = dict(games=games, templates=templates, official=official, identities=identities, schedule=schedule,
                   historical_input_status='retrieved_2026_10_27_not_contemporaneous', sources=history['sources'])
    write_gzip(out/'inputs.json.gz', dataset)
    write(out/'raw-reconciliation.json', dict(games=len(audits), shot_point_agreement=sum(a['passed'] for a in audits.values()),
         usable_joint_templates=len(templates), source_sha256={str(p.relative_to(repo)):file_hash(p) for p in paths.values()},
         original_history_sha256=file_hash(history_path), audits=audits,
         observed='shot events and credited box outcomes', inferred='lineup seeds and possession grouping',
         unavailable=['native_vendor_JSON','historical_injuries','original_local_model_forecasts','verified_debuts']))
    return dataset


def eligible(games, origin, season, lag=36, strict=False):
    return [g for g in games if season-3 <= g['season'] <= season and utc(g['tipoff'])+timedelta(hours=lag) < origin
            and (not strict or utc(g['known_at']) < origin)]


def targets(data, start, end):
    first = {}
    for g in data['schedule']:
        day = utc(g['tipoff']).astimezone(EASTERN).date().isoformat()
        if start <= day <= end and (day not in first or (g['tipoff'], g['game_id']) < (first[day]['tipoff'], first[day]['game_id'])):
            first[day] = dict(g, date=day)
    return [first[d] for d in sorted(first)]


def field(data, target, lag=36):
    origin = utc(target['tipoff'])-timedelta(hours=6)
    history = eligible(data['games'], origin, target['season'], lag)
    players = []
    for team in (target['home'], target['away']):
        past = [g for g in history if g['season'] == target['season'] and team in (g['home'], g['away'])]
        if len(past) < 5:
            raise ValueError('insufficient_team_warmup')
        last = max(past, key=lambda g: (g['tipoff'], g['game_id']))
        roster = [dict(p, game_id=target['game_id'], roster_source_game=last['game_id']) for p in last['players'] if p['team'] == team]
        if len(roster) < 10:
            raise ValueError('insufficient_prior_roster')
        # Only identities and prior-game values; no current outcome is accessed here.
        players.extend({k:p[k] for k in ('player_id','name','position','team','game_id','roster_source_game')} for p in roster)
    if len({p['player_id'] for p in players}) != len(players):
        raise ValueError('duplicate_proxy_player')
    return dict(target, origin=origin.isoformat(), players=players), history


def outcomes(data, slate):
    rows, missing = [], []
    official = data['official'].get(slate['game_id'], {})
    for p in slate['players']:
        nba = data['identities'].get(p['player_id'])
        q = official.get(str(nba)) if nba is not None else None
        if q is None or not q['explicit_outcome'] or q['team'] != p['team']:
            rows.append(None)
            missing.append(p['player_id'])
        else:
            rows.append(q)
    return rows, missing
