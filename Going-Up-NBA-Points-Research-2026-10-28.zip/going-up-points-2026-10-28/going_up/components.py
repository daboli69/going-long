"""Development-only component checks; oracle sensitivity is not causal attribution."""
import argparse
from pathlib import Path
import sys
import numpy as np
from .data import field,outcomes,targets
from .io import read,utc,write,write_gzip
from .metrics import crps_sorted,pmf_of,row,aggregate,paired
from .model import context,simulate
from .run import PERIODS


def run(data,development,repo,output):
    if str(repo) not in sys.path:sys.path.insert(0,str(repo))
    from scripts.king_court_diagnostics.dataset import profiles as old_profiles
    from scripts.king_court.simulation import simulate as old_simulate
    selected=read(development)['chosen']
    original_scores=read(Path(development).parent/'development-scores.json.gz')['C']
    existing=read(Path(development).parent/'development-forecasts.json.gz')[:12]
    ids={f['game_id'] for f in existing};rows=[];uniform=[]
    for number,t in enumerate(targets(data,*PERIODS['development'])):
        if t['game_id'] not in ids:continue
        s,h=field(data,t);pp=context(s,h,selected);truth,_=outcomes(data,s)
        c=simulate(s,pp,data['templates'],selected,2000,281026+number*1009)
        old_s=dict(s,games=[{k:s[k] for k in ('game_id','home','away','tipoff')}])
        old_p,team,ot,_=old_profiles(dict(games=data['games'],debut_seasons={}),old_s,
            dict(season_decay=.65,game_half_life_days=selected['half_life'],prior_games=selected['prior_games']))
        b=old_simulate(old_s,old_p,team,ot,2000,281026+number*1009)
        for j,p in enumerate(pp):
            if truth[j] is None:continue
            y=truth[j]
            own=p['own'];sample=np.array([r['pts'] for r in own],dtype=int)
            if len(sample):uniform.append(row(pmf_of(sample),y,s['game_id'],p['player_id'],s['date']))
            for name,sim in [('C',c),('B_reconstruction',b)]:
                m=sim['minutes'][:,j];q=np.quantile(m,[.1,.9])
                r=dict(model=name,game_id=s['game_id'],player_id=p['player_id'],minutes_actual=y['minutes'],
                    minutes_mean=float(m.mean()),minutes_mae=abs(float(m.mean())-y['minutes']),minutes_crps=crps_sorted(m,y['minutes']),
                    minutes_coverage80=int(q[0]<=y['minutes']<=q[1]),minutes_zero_probability=float((m==0).mean()),
                    actual_nonparticipation=int(y['minutes']==0),points_residual=y['pts']-float(sim['points'][:,j].mean()),
                    minutes_residual=y['minutes']-float(m.mean()))
                r['participation_brier']=(1-r['minutes_zero_probability']-int(y['minutes']>0))**2
                if name=='C':
                    for stat in ('fga','fta'):
                        x=sim[stat][:,j];r[stat+'_mae']=abs(float(x.mean())-y[stat]);r[stat+'_crps']=crps_sorted(x,y[stat])
                rows.append(r)
    summaries={}
    for name in ('C','B_reconstruction'):
        rr=[r for r in rows if r['model']==name]
        summary={k:float(np.mean([r[k] for r in rr])) for k in ('minutes_mae','minutes_crps','minutes_coverage80','minutes_zero_probability','actual_nonparticipation','participation_brier')}
        if name=='C':
            for k in ('fga_mae','fta_mae','fga_crps','fta_crps'):summary[k]=float(np.mean([r[k] for r in rr]))
        summary['points_minutes_residual_correlation']=float(np.corrcoef([[r['points_residual'] for r in rr],[r['minutes_residual'] for r in rr]])[0,1])
        summary['n']=len(rr);summaries[name]=summary
    ids={(r['game_id'],r['player_id']) for r in uniform}
    base=[r for r in original_scores if (r['game_id'],r['player_id']) in ids]
    write_gzip(output/'component-rows.json.gz',rows)
    write(output/'components.json',dict(period='development_first_12_eligible_games_only',summary=summaries,
        uniform_prior_outcomes=aggregate(uniform),candidate_minus_uniform=paired(uniform,base),
        interpretation='Associational residual diagnostics and conditional oracles do not identify causal error shares or irreducible uncertainty.'))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--inputs',type=Path,required=True);p.add_argument('--development',type=Path,required=True);p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();run(read(a.inputs),a.development,a.repo,a.output)
