"""Render evidence already evaluated; never selects parameters or revises criteria."""
import argparse
from pathlib import Path
import numpy as np
from .io import read


def render(assessment,development,components,out,diagnostics):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    a,d,c=read(assessment),read(development),read(components)
    corrected=read(diagnostics)
    d=dict(d,ablation=corrected['ablation'])
    periods=a['periods'];out=Path(out);out.mkdir(parents=True,exist_ok=True)
    fig,ax=plt.subplots(2,2,figsize=(11,8),layout='constrained')
    names=['A','B_reconstruction','C'];labels=['Prior outcomes','Frozen-code proxy','Generative candidate']
    colors=['#747b82','#b67d30','#177a79']
    for j,period in enumerate(('stress','later')):
        s=periods[period]['summary'];base=np.arange(3)
        ax[0,j].bar(base,[s[n]['crps'] for n in names],color=colors)
        ax[0,j].set_xticks(base,labels,rotation=13);ax[0,j].set_ylabel('Player-points CRPS (lower better)')
        ax[0,j].set_title(period+' reused chronology')
        for i,n in enumerate(names):ax[0,j].text(i,s[n]['crps'],f"{s[n]['crps']:.3f}",ha='center',va='bottom')
        ax[1,0].plot([.5,.8,.95],[s['C']['coverage0.5'],s['C']['coverage0.8'],s['C']['coverage0.95']],marker='o',label=period)
    ax[1,0].plot([.5,.95],[.5,.95],'k--',lw=1);ax[1,0].set_xlabel('Nominal interval mass');ax[1,0].set_ylabel('Observed coverage');ax[1,0].legend()
    pit=periods['later']['summary']['C']['PIT_bins'];ax[1,1].bar(np.arange(10),np.array(pit)/sum(pit),color=colors[2]);ax[1,1].axhline(.1,color='k',linestyle='--',lw=1)
    ax[1,1].set_xlabel('Randomized discrete PIT decile');ax[1,1].set_ylabel('Fraction of later outcomes')
    fig.suptitle('Going Up: chronological diagnostics; historical input receipts and local model unavailable',fontsize=12)
    fig.savefig(out/'diagnostics.png',dpi=160);fig.savefig(out/'diagnostics.svg');plt.close(fig)
    lines=['# Going Up: independent player-points study','',
       'This is a basketball-only, isolated research experiment. No production model was changed. Historical results below are reused chronological replays with assumed result publication lags and prior-roster proxies; they are not genuine historical pregame forecasts.','',
       '## 1. Does the candidate outperform the existing model?','',
       'That primary question cannot be resolved: the Windows player-points model and its immutable forecasts were unavailable. B below is unchanged KOTC v1 code reconstructed on the same earlier roster proxy, with an explicit unknown-experience adapter. It is an auxiliary reference, not the local production model. A is an outcomes-only empirical baseline. C is the one generative candidate.','',
       '## 2. Size and uncertainty','',
       '| Period/model | Games | Player-games | CRPS | MAE | 80% coverage |','| --- | ---: | ---: | ---: | ---: | ---: |']
    for period in ('stress','later'):
        for name in names:
            s=periods[period]['summary'][name];lines.append(f"| {period}/{name} | {s['games']} | {s['observations']} | {s['crps']:.4f} | {s['mae']:.4f} | {s['coverage0.8']:.2%} |")
    lines+=['','C-minus-reference CRPS and approximate paired game/player-cluster 95% intervals:','']
    for period in ('stress','later'):
        for name,r in periods[period]['candidate_minus'].items():lines.append(f"- {period}, {name}: {r['delta']:+.4f}, interval [{r['game_player_95'][0]:+.4f}, {r['game_player_95'][1]:+.4f}], relative reduction {r['relative_reduction']:.2%}.")
    lines+=['','These intervals account for crossed observed game/player clusters approximately. Week/player sensitivity, game-only/player-only intervals, missing-outcome bounds, both simulation seeds and full paired rows are retained in the assessment artifacts. They do not correct missing source publication evidence or roster selection.','',
        '## 3. Which scoring components explain errors?','',
        'The study does not identify additive causal error shares. Development-only oracle and removal tests measure conditional sensitivity with interactions. Component diagnostics use the first 12 eligible development games; no assessment ablations or rescue tuning occurred. Two diagnostic defects were corrected before assessment while preserving original receipts and proving actual candidate samples unchanged: player-ID alignment under the 72-hour lag, and recorded-minute conditioning for the nested individual-attempt oracle.','']
    for name,s in c['summary'].items():lines.append(f"- {name}: minutes CRPS {s['minutes_crps']:.3f}, minutes MAE {s['minutes_mae']:.3f}, nonparticipation Brier {s['participation_brier']:.4f}; points/minutes residual correlation {s['points_minutes_residual_correlation']:.3f}.")
    for name,s in d['ablation'].items():
        r=s['paired_vs_C']
        if r.get('observations'):lines.append(f"- Development {name}: CRPS change {r['delta']:+.4f} on {r['observations']} matched player-games. Recorded-outcome variants are oracles, not attainable predictions.")
    lines+=['','## 4. Reducible versus unpredictable uncertainty','',
        'Reliable pregame participation, current role, roster membership and historical data versions are potentially reducible input uncertainties. Shot conversion, possession variation and actual rotation choices retain stochastic variation. The available data cannot identify a numerical irreducible-error floor. More draws only reduce Monte Carlo error.','',
        '## 5. Generalization across time','',
        'The two later historical periods are evaluated once after development selection, but their source archives were already inspected in earlier research. Direction, magnitude, calibration and extremes must be read across both; neither is an untouched confirmation set. Strict contemporaneous-source enforcement yielded '+str(a['strict_contemporaneous_eligible_forecasts'])+' eligible historical forecasts.','',
        '## 6. Falsification and predictive checks','',
        'All extreme outcomes remain in primary scores. >=30/>=40 event reliability and loss, discrete PIT, interval coverage, residuals, finite-support log-score failures, a second simulation seed, crossed-cluster and week-cluster intervals are retained. Development tests simplify opportunities, remove/increase pooling, remove latent conversion variation and impose a 72-hour result embargo. Cohort changes in that lag test are excluded from paired comparisons and logged. Historical injury inputs are entirely excluded.','',
        'The candidate must clear at least .10 point and 2% CRPS improvement, a clustered upper interval below zero against A and a valid B, calibration/MAE gates and untouched point-in-time evidence. Retrospective numerical superiority alone cannot clear those criteria.','',
        '## 7. Independent evidence and reproduction','',
        'All 1,230 ending-year-2026 regular-season games reconciled point, FGA/FGM, 3PA/3PM and FTA/FTM credits against NBA boxes in the independent shot parser. 1,182 joint templates also met the exact-team-minute requirements. Original event/stint checks were independently rerun; native vendor JSON and independent lineup seeds remain absent. Scoring uses the CDF identity and is independently recomputed from saved forecast PMFs through the energy identity. Code/input versions, deterministic ordering, seeds, code lock, forecasts, outcomes, exclusions and source hashes are retained.','',
        'Log scores are not rescued with arbitrary floors: finite Monte Carlo/empirical support can assign zero mass to observed counts, so a reliable full log-score comparison is unavailable. This limitation remains explicit.','',
        '## 8. Is further forward testing justified?','',
        'The artifacts are suitable for a preregistered research-only forward comparison if complete actual-time rosters, source receipts and immutable local-model forecasts can be obtained. This is not evidence to replace a model. The future reservation was extended before future outcomes to November 1, 2026–February 28, 2027 because the original month could not meet the sample minimum. No future forecasts, outcomes, scheduler or deployment were created.','',
        '![Diagnostics](diagnostics.png)','',
        'Inconclusive: insufficient reliable evidence']
    with (out/'REPORT.md').open('x',encoding='utf-8') as f:f.write('\n'.join(lines)+'\n')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--assessment',type=Path,required=True);p.add_argument('--development',type=Path,required=True);p.add_argument('--components',type=Path,required=True);p.add_argument('--diagnostics',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();render(a.assessment,a.development,a.components,a.output,a.diagnostics)
