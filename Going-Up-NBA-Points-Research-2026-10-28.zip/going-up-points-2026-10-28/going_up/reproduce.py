"""Recalculate old claims and all new CRPS without trusting saved score fields."""
import argparse
from pathlib import Path
import sys
import numpy as np
from .io import read, write
from .metrics import crps_cdf


def verify_new(forecast_path,score_path):
    forecasts=read(forecast_path);scores=read(score_path)
    lookup={name:{(r['game_id'],r['player_id']):r for r in rr} for name,rr in scores.items()}
    maximum=0.;count=0
    for g in forecasts:
        for p in g['players']:
            if p['observed'] is None:continue
            for name,pmf in p['models'].items():
                # Deliberately use the energy identity on weighted support,
                # separate from CDF scorer and raw-sample order-statistic check.
                probs=np.array(pmf);x=np.arange(len(probs));y=p['observed']['pts']
                energy=float(abs(x-y)@probs-.5*np.sum(abs(x[:,None]-x)*(probs[:,None]*probs)))
                cdf=crps_cdf(pmf,y)
                saved=lookup[name][(g['game_id'],p['player_id'])]['crps']
                maximum=max(maximum,abs(energy-cdf),abs(energy-saved));count+=1
    if maximum>1e-10:raise AssertionError('Independent score disagreement')
    return dict(independently_scored_forecasts=count,maximum_absolute_difference=maximum,
                identity='E|X-y| - .5 E|X-Xprime| on finite weighted support')


def verify_old(repo,output):
    repo=Path(repo)
    if str(repo) not in sys.path:sys.path.insert(0,str(repo))
    from scripts.king_court.common import load_sealed
    from scripts.king_court_diagnostics.dataset import collect_slates,profiles
    from scripts.king_court.simulation import simulate
    winner=read(repo/'.cache/nba-winners/development-final.json')
    f=winner['forecasts'];y=np.array([r['actual'] for r in f])
    models={name:np.array([r['probabilities'][name] for r in f]) for name in f[0]['probabilities']}
    models.update(ensemble=np.array([r['home_probability'] for r in f]),
        equal_weight=np.array([r['equal_weight_home_probability'] for r in f]),home_frequency=np.array([r['home_frequency'] for r in f]))
    scores={};diff=0;metric_differences={}
    for name,p in models.items():
        rr=dict(brier=float(np.mean((p-y)**2)),log_loss=float(np.mean(-y*np.log(p)-(1-y)*np.log1p(-p))),accuracy=float(np.mean((p>=.5)==y)))
        scores[name]=rr
        for k,v in rr.items():
            dd=v-winner['report']['metrics'][name][k]
            diff=max(diff,abs(dd));metric_differences[name+'_'+k]=dd
    history=load_sealed(repo/'.cache/king-court-deepening/combined-history.json')
    # Archived manifests use repo-relative paths. Resolve only the in-memory
    # reader copy; leave original sealed bytes unchanged.
    history=dict(history,sources=[dict(s,path=str(repo/s['path'])) for s in history['sources']])
    saved=load_sealed(repo/'.cache/king-court-deepening/registered-comparison.json')
    slates,_=collect_slates(history,['2026-01-06']);slate=slates[0]
    saved_order=[r['player_id'] for r in saved['per_slate']['original'][0]['players']]
    collected_order=[p['player_id'] for p in slate['players']]
    by_id={p['player_id']:p for p in slate['players']}
    if set(saved_order)!=set(by_id):raise ValueError('Retained cohort changed')
    # The old collector sorts equal-tipoff games without a secondary key.
    # Reconstruct the actual retained order instead of pretending the seed
    # uniquely determines that order across Python hash seeds.
    slate['players']=[by_id[pid] for pid in saved_order]
    game_rank={}
    for p in slate['players']:game_rank.setdefault(p['game_id'],len(game_rank))
    slate['games']=sorted(slate['games'],key=lambda g:game_rank[g['game_id']])
    pp,teams,ot,_=profiles(history,slate,saved['parameter_choice']['parameters'])
    draws=simulate(slate,pp,teams,ot,5000,271026)['pra']
    prior={r['player_id']:r for r in saved['per_slate']['original'][0]['players']}
    discrepancies=[];detail=[]
    for j,p in enumerate(pp):
        y=sum(slate['outcomes'][p['player_id']][k] for k in ('points','rebounds','assists'))
        score=crps_cdf(np.bincount(draws[:,j])/len(draws),y)
        discrepancies.append(abs(score-prior[p['player_id']]['crps']))
        detail.append(dict(player_id=p['player_id'],recomputed=score,retained=prior[p['player_id']]['crps'],mean=float(draws[:,j].mean()),retained_mean=prior[p['player_id']]['mean']))
    write(output,dict(winner=dict(observations=len(f),recomputed_metrics=scores,maximum_absolute_report_difference=diff,metric_differences=metric_differences),
        KOTC=dict(date='2026-01-06',draws=5000,players=len(pp),maximum_CRPS_difference=max(discrepancies),
            exact_reproduction=bool(max(discrepancies)<1e-10),detail=detail,
            recorded_order_restored=True,collector_order_was_different=collected_order!=saved_order,
            reproducibility_gap='Old game collector sorts a set by tipoff only; equal-tipoff game order depends on Python hash order. Retained player order reconstructs the historical stream assignment.',
            status='Reproduction attempt of conditional postgame-field diagnostic, not a pregame accuracy claim'),
        original_player_points_forecasts_available=0,
        limitations='One old slate simulation and all saved winner forecast scores reproduced; not a new holdout, not the unavailable Windows app.'))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--repo',type=Path);p.add_argument('--forecasts',type=Path);p.add_argument('--scores',type=Path);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    if a.forecasts:write(a.output,verify_new(a.forecasts,a.scores))
    elif a.repo:verify_old(a.repo,a.output)
    else:p.error('Need --repo or --forecasts plus --scores')
