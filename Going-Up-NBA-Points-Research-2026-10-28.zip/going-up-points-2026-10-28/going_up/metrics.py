"""Proper discrete scores and explicitly approximate crossed-cluster uncertainty."""
from hashlib import sha256
import numpy as np


def pmf_of(x):
    x=np.asarray(x)
    if x.ndim!=1 or not np.issubdtype(x.dtype,np.integer) or np.any(x<0):
        raise ValueError('Nonnegative integer sample required')
    return np.bincount(x)/len(x)


def crps_cdf(pmf,y):
    p=np.asarray(pmf,dtype=float)
    if y<0 or int(y)!=y or np.any(p<0) or not np.isclose(p.sum(),1):
        raise ValueError('Invalid discrete distribution/outcome')
    limit=max(len(p),int(y)+1)
    cdf=np.pad(np.cumsum(p),(0,limit-len(p)),constant_values=1)
    return float(np.sum((cdf-(np.arange(limit)>=y))**2))


def crps_sorted(x,y):
    """Independent E|X-y|-E|X-X'|/2 implementation for raw samples."""
    x=np.sort(np.asarray(x,dtype=float));n=len(x)
    return float(np.mean(abs(x-y))-np.dot(2*np.arange(1,n+1)-n-1,x)/(n*n))


def row(pmf,truth,game,player,date,samples=None):
    p=np.asarray(pmf);x=np.arange(len(p));cdf=np.cumsum(p)
    y=int(truth['pts']);mean=float(x@p)
    q=lambda v:int(min(len(p)-1,np.searchsorted(cdf,v)))
    bounds={str(v):[q((1-v)/2),q((1+v)/2)] for v in (.5,.8,.95)}
    uniform=int.from_bytes(sha256((game+'|'+player).encode()).digest()[:8],'big')/2**64
    below=float(cdf[min(y-1,len(p)-1)]) if y else 0.
    mass=float(p[y]) if y<len(p) else 0.
    r=dict(game_id=game,player_id=player,date=date,actual=y,mean=mean,variance=float(((x-mean)**2)@p),
        crps=crps_cdf(p,y),mae=abs(mean-y),bias=mean-y,
        pit=below+uniform*mass,zero_probability=float(p[0]),actual_zero=int(y==0),
        probability_ge30=float(p[30:].sum()),actual_ge30=int(y>=30),
        probability_ge40=float(p[40:].sum()),actual_ge40=int(y>=40),
        q95=q(.95),above_q95=int(y>q(.95)),intervals=bounds,
        log_score=None if mass==0 else float(-np.log(mass)),log_zero_mass=mass==0)
    for level,(lo,hi) in bounds.items():
        r['coverage'+level]=int(lo<=y<=hi)
        r['forecast_mass'+level]=float(p[lo:hi+1].sum())
    if samples is not None:
        batches=np.array_split(samples,8)
        vals=np.array([crps_sorted(z,y) for z in batches])
        r['crps_mc_se']=float(vals.std(ddof=1)/np.sqrt(len(vals)))
        r['mean_mc_se']=float(np.std(samples,ddof=1)/np.sqrt(len(samples)))
        r['crps_independent_difference']=float(crps_sorted(samples,y)-r['crps'])
    return r


def aggregate(rows):
    if not rows:return {'observations':0}
    result=dict(observations=len(rows),games=len({r['game_id'] for r in rows}),players=len({r['player_id'] for r in rows}))
    for k in ('crps','mae','bias','variance','coverage0.5','coverage0.8','coverage0.95','forecast_mass0.5','forecast_mass0.8','forecast_mass0.95','above_q95','zero_probability','actual_zero'):
        result[k]=float(np.mean([r[k] for r in rows]))
    for k in ('ge30','ge40'):
        prob=np.array([r['probability_'+k] for r in rows]);actual=np.array([r['actual_'+k] for r in rows])
        result[k]=dict(predicted=float(prob.mean()),observed=float(actual.mean()),brier=float(np.mean((prob-actual)**2)),reliability=[])
        for lo,hi in [(0,.01),(.01,.05),(.05,.1),(.1,.25),(.25,.5),(.5,1.000001)]:
            take=(prob>=lo)&(prob<hi)
            if take.any():result[k]['reliability'].append(dict(lower=lo,upper=min(1,hi),n=int(take.sum()),predicted=float(prob[take].mean()),observed=float(actual[take].mean())))
    result['PIT_bins']=np.histogram([r['pit'] for r in rows],bins=np.linspace(0,1,11))[0].tolist()
    result['zero_predictive_mass_outcomes']=sum(r['log_zero_mass'] for r in rows)
    result['log_score']=None if result['zero_predictive_mass_outcomes'] else float(np.mean([r['log_score'] for r in rows]))
    result['log_score_status']='not_reliable_for_finite_MC_or_finite_empirical_support; no_probability_floor_rescue'
    for threshold in (30,40):
        take=[r for r in rows if r['actual']>=threshold]
        result['observed_tail_'+str(threshold)]=dict(n=len(take),crps=float(np.mean([r['crps'] for r in take])) if take else None,mae=float(np.mean([r['mae'] for r in take])) if take else None)
    mc=[r['crps_mc_se'] for r in rows if 'crps_mc_se' in r]
    result['average_per_forecast_crps_mc_se']=float(np.mean(mc)) if mc else 0.
    return result


def paired(a,b,draws=2000,seed=281026):
    """b-a, preserving every observed game/player intersection."""
    key=lambda r:(r['game_id'],r['player_id'])
    aa={key(r):r for r in a};bb={key(r):r for r in b}
    if set(aa)!=set(bb):raise ValueError('Unmatched paired observations')
    keys=sorted(aa)
    if not keys:return {'observations':0}
    delta=np.array([bb[k]['crps']-aa[k]['crps'] for k in keys])
    games={k:i for i,k in enumerate(sorted({k[0] for k in keys}))}
    players={k:i for i,k in enumerate(sorted({k[1] for k in keys}))}
    weeks=sorted({aa[k]['date'][:4]+'-'+str(__import__('datetime').date.fromisoformat(aa[k]['date']).isocalendar().week) for k in keys})
    weeks={w:i for i,w in enumerate(weeks)}
    gi=np.array([games[k[0]] for k in keys]);pi=np.array([players[k[1]] for k in keys])
    wi=np.array([weeks[aa[k]['date'][:4]+'-'+str(__import__('datetime').date.fromisoformat(aa[k]['date']).isocalendar().week)] for k in keys])
    rng=np.random.default_rng(seed)
    counts=lambda n:rng.multinomial(n,np.full(n,1/n),size=draws)
    g,p,w=counts(len(games)),counts(len(players)),counts(len(weeks))
    result=dict(observations=len(keys),games=len(games),players=len(players),delta=float(delta.mean()),
         relative_reduction=float(-delta.mean()/np.mean([aa[k]['crps'] for k in keys])),
         uncertainty='paired crossed count-bootstrap; finite-sample approximate, can be conservative; not input-validity correction')
    for name,weight in [('game',g[:,gi]),('player',p[:,pi]),('game_player',g[:,gi]*p[:,pi]),('week_player',w[:,wi]*p[:,pi])]:
        sums=weight.sum(axis=1);ok=sums>0
        values=weight[ok]@delta/sums[ok]
        result[name+'_95']=np.quantile(values,[.025,.975]).tolist()
    return result


def missing_outcome_bounds(forecasts,reference='A'):
    """Sharp pointwise CRPS-difference bounds; no unknown outcome is invented.

    For y beyond both finite supports the loss difference is constant, so the
    finite enumeration also covers every nonnegative integer outcome.
    """
    observed,unknown_lo,unknown_hi=[],[],[]
    for game in forecasts:
        for p in game['players']:
            a=p['models'][reference];c=p['models']['C']
            if p['observed'] is not None:
                y=p['observed']['pts'];observed.append(crps_cdf(c,y)-crps_cdf(a,y))
            else:
                values=[crps_cdf(c,y)-crps_cdf(a,y) for y in range(max(len(a),len(c))+1)]
                unknown_lo.append(min(values));unknown_hi.append(max(values))
    n=len(observed)+len(unknown_lo)
    return dict(observed=len(observed),unknown=len(unknown_lo),
        full_proxy_field_delta_bounds=[(sum(observed)+sum(unknown_lo))/n,(sum(observed)+sum(unknown_hi))/n] if n else None,
        interpretation='Worst/best pointwise nonnegative-integer outcomes, not imputed data or joint roster feasibility')
