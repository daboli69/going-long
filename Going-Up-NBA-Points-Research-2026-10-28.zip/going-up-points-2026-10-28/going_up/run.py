"""Finite, append-only research commands. No production, alerts or network calls."""
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import itertools
import json
from pathlib import Path
import platform
import sys
import numpy as np

from .data import eligible, field, outcomes, prepare, targets
from .io import file_hash, read, utc, write, write_gzip
from .metrics import aggregate, missing_outcome_bounds, paired, pmf_of, row
from .model import baseline, context, simulate

ROOT=Path(__file__).resolve().parents[1]
PERIODS={'development':('2025-11-01','2025-12-31'),
         'stress':('2026-01-01','2026-02-28'), 'later':('2026-03-01','2026-04-12')}


def preserved(repo):
    r=read(ROOT/'registration.json')
    if file_hash(ROOT/'PLAN.md')!=r['plan_sha256'] or file_hash(ROOT/'AUDIT.md')!=r['audit_sha256']:
        raise ValueError('Frozen study audit/plan changed')
    if (repo/'REFERENCE_MANIFEST.json').is_file():
        reference=read(repo/'REFERENCE_MANIFEST.json')
        errors=[name for name,value in reference['files'].items() if not (repo/name).is_file() or file_hash(repo/name)!=value]
        if errors:raise ValueError('Bundled frozen reference changed: '+str(errors))
        # This does not claim to verify absent original raw caches.
        return dict(scope='bundled_original_source_and_reports_only',files=len(reference['files']),original_raw_cache_verified=False)
    errors=[name for name,value in r['preserved_files'].items() if not (repo/name).exists() or file_hash(repo/name)!=value]
    if file_hash(ROOT/'PLAN.md')!=r['plan_sha256'] or file_hash(ROOT/'AUDIT.md')!=r['audit_sha256']:
        errors.append('frozen_study_plan_or_audit')
    if errors:raise ValueError('Preservation failure: '+str(errors))
    return len(r['preserved_files'])


def code_hashes():
    return {str(p.relative_to(ROOT)):file_hash(p) for p in sorted((ROOT/'going_up').glob('*.py'))}


def auxiliary_v1(repo,data,slate,parameters,draws,seed):
    # This explicit adapter is study-local. It never edits or imports the app.
    if str(repo) not in sys.path:sys.path.insert(0,str(repo))
    from scripts.king_court_diagnostics.dataset import profiles
    from scripts.king_court.simulation import simulate as original
    args=dict(season_decay=.65,game_half_life_days=parameters['half_life'],prior_games=parameters['prior_games'])
    s=dict(slate,games=[{k:slate[k] for k in ('game_id','home','away','tipoff')}])
    pp,teams,ot,_=profiles(dict(games=data['games'],debut_seasons={}),s,args)
    return original(s,pp,teams,ot,draws,seed)['points']


def run_period(data,period,parameters,draws,seed,repo,include_v1=False,second=False,selection_only=False):
    rows={'C':[]};forecasts=[];exclusions=[]
    if not selection_only:rows['A']=[]
    if include_v1:rows['B_reconstruction']=[]
    if second:rows['C_second_seed']=[]
    selection=targets(data,*PERIODS[period])
    reconciled={g['game_id'] for g in data['templates']}
    for number,target in enumerate(selection):
        if target['game_id'] not in reconciled:
            exclusions.append(dict(game_id=target['game_id'],date=target['date'],reason='target_shots_or_exact_team_minutes_unreconciled'))
            continue
        try:
            slate,history=field(data,target)
            pp=context(slate,history,parameters)
            sim=simulate(slate,pp,data['templates'],parameters,draws,seed+number*1009)
        except ValueError as error:
            exclusions.append(dict(game_id=target['game_id'],date=target['date'],reason=str(error)))
            continue
        predictions={'C':[pmf_of(sim['points'][:,j]) for j in range(len(pp))]}
        if not selection_only:predictions['A']=baseline(pp,utc(slate['origin']),slate['season'])
        raw={'C':sim['points']}
        if include_v1:
            raw['B_reconstruction']=auxiliary_v1(repo,data,slate,parameters,draws,seed+number*1009)
            predictions['B_reconstruction']=[pmf_of(raw['B_reconstruction'][:,j]) for j in range(len(pp))]
        if second:
            raw['C_second_seed']=simulate(slate,pp,data['templates'],parameters,draws,281027+number*1009)['points']
            predictions['C_second_seed']=[pmf_of(raw['C_second_seed'][:,j]) for j in range(len(pp))]
        actual,missing=outcomes(data,slate)
        if missing:exclusions.append(dict(game_id=slate['game_id'],date=slate['date'],reason='unknown_target_outcome_not_zero',player_ids=missing))
        strict=eligible(data['games'],utc(slate['origin']),slate['season'],strict=True)
        result=dict(game_id=slate['game_id'],date=slate['date'],origin=slate['origin'],recorded_at=datetime.now(timezone.utc).isoformat(),
             kind='retrospective_assumed_result_lag_prior_roster_proxy_NOT_actual_time_freeze',
             strict_contemporaneous_history_games=len(strict),unknown_outcomes=len(missing),players=[],diagnostics=sim['diagnostics'],
             history_max_tipoff=max(g['tipoff'] for g in history),parameters=parameters,seed=seed+number*1009,draws=draws)
        for j,p in enumerate(pp):
            entry={k:p[k] for k in ('player_id','name','team','position','roster_source_game','evidence','role_evidence','prior_rate_share','experience')}
            entry['models']={name:pmfs[j].tolist() for name,pmfs in predictions.items()}
            entry['observed']=actual[j]
            if actual[j] is not None:
                for name,pmfs in predictions.items():
                    rr=row(pmfs[j],actual[j],slate['game_id'],p['player_id'],slate['date'],raw[name][:,j] if name in raw else None)
                    rr['roster_source_game']=p['roster_source_game']
                    rows[name].append(rr)
            result['players'].append(entry)
        if not selection_only:forecasts.append(result)
        print(json.dumps(dict(stage=period,game=number+1,of=len(selection),id=slate['game_id'],scored=len(pp)-len(missing))),flush=True)
    return rows,forecasts,exclusions


def development(data,out,repo):
    candidates=[]
    for half,prior in itertools.product((30,90),(5,15)):
        p=dict(half_life=half,prior_games=prior,season_decay=.65)
        rr,_,exc=run_period(data,'development',p,2000,281026,repo,selection_only=True)
        candidates.append(dict(parameters=p,scores=aggregate(rr['C']),excluded=exc))
    candidates.sort(key=lambda x:(x['scores']['crps'],x['parameters']['half_life'],x['parameters']['prior_games']))
    chosen=candidates[0]['parameters']
    rows,forecasts,exc=run_period(data,'development',chosen,2000,281026,repo,include_v1=True)
    # The first 12 eligible development games, determined by history/template support.
    ablation={name:[] for name in ('observed_minutes','fixed_pace','observed_team_pools','observed_individual_attempts','fixed_conversion','simple_opportunity','no_pooling','strong_pooling','lag72')}
    notes=[]
    selected_ids={f['game_id'] for f in forecasts[:12]}
    for number,target in enumerate(targets(data,*PERIODS['development'])):
        if target['game_id'] not in selected_ids:continue
        slate,history=field(data,target);pp=context(slate,history,chosen)
        actual,missing=outcomes(data,slate)
        official=data['official'].get(slate['game_id'],{})
        all_minutes=sum(q['minutes'] or 0 for q in official.values())/10
        oracle=not missing and abs(sum(q['minutes'] for q in actual)/10-all_minutes)<.05
        for name in ablation:
            if name.startswith('observed_') and not oracle:
                notes.append(dict(game_id=slate['game_id'],ablation=name,reason='incomplete_oracle_field'));continue
            try:
                sp=dict(slate,observed_game_length=all_minutes)
                par=dict(chosen)
                if name=='lag72':
                    par['lag_hours']=72
                    sp,hp=field(data,target,lag=72);pr=context(sp,hp,par)
                    # Changing prior fields changes the estimand. Restrict to original field intersection.
                    if {p['player_id'] for p in pr}!={p['player_id'] for p in pp}:
                        notes.append(dict(game_id=slate['game_id'],ablation=name,reason='changed_prior_proxy_field_unpaired'));continue
                    pr_by_id={p['player_id']:p for p in pr}
                    pr=[pr_by_id[p['player_id']] for p in pp]
                else:pr=pp
                sim=simulate(sp,pr,data['templates'],par,2000,281026+number*1009,None if name=='lag72' else name,actual)
                for j,p in enumerate(pp):
                    if actual[j] is not None:
                        ablation[name].append(row(pmf_of(sim['points'][:,j]),actual[j],slate['game_id'],p['player_id'],slate['date']))
            except ValueError as error:notes.append(dict(game_id=slate['game_id'],ablation=name,reason=str(error)))
    write_gzip(out/'development-forecasts.json.gz',forecasts)
    write_gzip(out/'development-scores.json.gz',rows)
    write_gzip(out/'development-ablation-scores.json.gz',ablation)
    comparisons={}
    for name,rr in ablation.items():
        ids={(r['game_id'],r['player_id']) for r in rr}
        base=[r for r in rows['C'] if (r['game_id'],r['player_id']) in ids]
        comparisons[name]=dict(scores=aggregate(rr),paired_vs_C=paired(base,rr))
    # Simpler outcomes-only A remains a fixed reference; no parameter rescue.
    result=dict(kind='development_selection_and_falsification_NOT_confirmation',candidates=candidates,chosen=chosen,
         summary={k:aggregate(v) for k,v in rows.items()},ablation=comparisons,ablation_notes=notes,
         exclusions=exc,parameters_selected_before_assessment=True,code_sha256=code_hashes())
    write(out/'development.json',result)
    return result


def lock(data_path,development_path,out,repo):
    preserved(repo)
    write(out,dict(locked_at=datetime.now(timezone.utc).isoformat(),code_sha256=code_hashes(),
          dataset_sha256=file_hash(data_path),development_sha256=file_hash(development_path),
          plan_sha256=file_hash(ROOT/'PLAN.md'),registration_sha256=file_hash(ROOT/'registration.json'),
          clarifications_sha256=file_hash(ROOT/'design-clarifications.json'),future_amendment_sha256=file_hash(ROOT/'future-confirmation-amendment.json'),
          diagnostics_sha256=file_hash(ROOT/'runs/diagnostics-003/corrections.json'),
          component_receipt_sha256=file_hash(ROOT/'runs/components-001/components.json'),
          historical_period_status='reused_not_untouched',future_outcomes=0))


def assess(data_path,development_path,lock_path,out,repo):
    lk=read(lock_path)
    if lk['code_sha256']!=code_hashes() or lk['dataset_sha256']!=file_hash(data_path) or lk['development_sha256']!=file_hash(development_path):
        raise ValueError('Study code/data/development changed after lock')
    for name,key in [('PLAN.md','plan_sha256'),('registration.json','registration_sha256'),('design-clarifications.json','clarifications_sha256'),('future-confirmation-amendment.json','future_amendment_sha256')]:
        if file_hash(ROOT/name)!=lk[key]:raise ValueError('Frozen study receipt changed: '+name)
    for name,key in [('runs/diagnostics-003/corrections.json','diagnostics_sha256'),('runs/components-001/components.json','component_receipt_sha256')]:
        if file_hash(ROOT/name)!=lk[key]:raise ValueError('Frozen development diagnostics changed: '+name)
    preserved(repo)
    data=read(data_path);chosen=read(development_path)['chosen'];periods={};all_forecasts=[]
    for period in ('stress','later'):
        rows,forecasts,exc=run_period(data,period,chosen,8000,281026,repo,True,True)
        write_gzip(out/(period+'-forecasts.json.gz'),forecasts)
        write_gzip(out/(period+'-scores.json.gz'),rows)
        summary={k:aggregate(v) for k,v in rows.items()}
        comparisons={name:paired(rows[name],rows['C']) for name in ('A','B_reconstruction')}
        paired_mc=paired(rows['C'],rows['C_second_seed'])
        all_forecasts.extend(forecasts)
        periods[period]=dict(summary=summary,candidate_minus=comparisons,second_seed_minus_primary=paired_mc,
             missing_outcome_bounds={name:missing_outcome_bounds(forecasts,name) for name in ('A','B_reconstruction')},exclusions=exc)
    result=dict(kind='independent_points_reused_chronological_study',periods=periods,
        code_lock_sha256=file_hash(lock_path),preserved_original_files=preserved(repo),
        strict_contemporaneous_eligible_forecasts=sum(f['strict_contemporaneous_history_games']>0 for f in all_forecasts),
        original_local_model_forecasts_available=0,future_confirmation_forecasts=0,future_confirmation_outcomes=0,
        market_inputs=False,production_modified=False,verdict='Inconclusive: insufficient reliable evidence',
        runtime=dict(python=platform.python_version(),numpy=np.__version__,polars=__import__('polars').__version__,scipy=__import__('scipy').__version__))
    write(out/'assessment.json',result)
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['prepare','develop','lock','assess','preserve'])
    parser.add_argument('--repo',type=Path,default=ROOT/'reference',help='Original cloud repo, or bundled frozen reference for portable reproduction')
    parser.add_argument('--inputs',type=Path,default=ROOT/'data/inputs.json.gz')
    parser.add_argument('--development',type=Path,default=ROOT/'runs/development/development.json')
    parser.add_argument('--lock',type=Path,default=ROOT/'code-lock.json')
    parser.add_argument('--output',required=True,type=Path)
    a=parser.parse_args();preserved(a.repo)
    if a.stage=='prepare':prepare(a.repo,a.output)
    elif a.stage=='develop':development(read(a.inputs),a.output,a.repo)
    elif a.stage=='lock':lock(a.inputs,a.development,a.output,a.repo)
    elif a.stage=='assess':assess(a.inputs,a.development,a.lock,a.output,a.repo)
    elif a.stage=='preserve':write(a.output,{'original_files_unchanged':preserved(a.repo)})


if __name__=='__main__':main()
