# Isolated Going Up research study

Read the report, audit, registered plan and Claude handoff before changes. Preserve original NBA models, snapshots, uncommitted work and the frozen study code/data/receipts. Use new output paths. The final assessment code lock must not be rewritten to disguise code changes. New experimental versions need a new dated registration. Do not add sportsbook information, markets, UI, alerts, jobs or production changes.

The portable reference contains old source/report bytes for an auxiliary comparator, not the user's current Windows application. Missing point-in-time records, unknown outcomes, unknown NBA debut metadata and uninspected app behavior stay unknown. Do not infer historical availability from final boxes, call bonus bets cash, promote unsupported models or present software tests as predictive validation.

The user has authorized ordinary reversible local inspection/integration toward their project goal. Do not infer an extra approval requirement for routine work from these instructions. Production/model-promotion rules remain separate.
