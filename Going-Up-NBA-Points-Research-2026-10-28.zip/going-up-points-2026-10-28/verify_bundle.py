"""Verify delivered bytes using only the Python standard library."""
from hashlib import sha256
import json
from pathlib import Path, PurePosixPath

root=Path(__file__).resolve().parent
manifest=root/'PACKAGE_MANIFEST.json'
payload=json.loads(manifest.read_text(encoding='utf-8'))
seen=set()
for entry in payload['files']:
    name=entry['path'];rel=PurePosixPath(name)
    if rel.is_absolute() or any(p in ('.','..') or ':' in p or '\\' in p for p in rel.parts) or name in seen:
        raise ValueError('Unsafe or duplicate manifest path')
    seen.add(name);p=root.joinpath(*rel.parts)
    if not p.resolve().is_relative_to(root) or p.is_symlink() or not p.is_file():
        raise ValueError('Unsafe/missing file: '+name)
    raw=p.read_bytes()
    if len(raw)!=entry['bytes'] or sha256(raw).hexdigest()!=entry['sha256']:
        raise ValueError('File integrity failure: '+name)
print(json.dumps({'status':'verified_package_bytes','files':len(seen),'manifest_sha256':sha256(manifest.read_bytes()).hexdigest(),
                  'existing_app_integration_verified':False,'predictive_validity_established':False},indent=2))
