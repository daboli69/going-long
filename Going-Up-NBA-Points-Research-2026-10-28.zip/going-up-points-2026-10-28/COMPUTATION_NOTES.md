# Computation and correction ledger

All entries below precede the first assessment unless explicitly labeled verification. They are implementation/provenance notes, not new model-selection opportunities.

- Read root AGENTS.md, CLAUDE.md, AUDIT_GUIDE and actual source/data before new implementation. Retained the initial git status and 56 original code/config/report/input SHA256s. Initial study registration: 2026-10-28 16:39:48 UTC.
- Installed dependencies into a separate cloud virtual environment. No original app environment was modified.
- Independently reran the old event/stint audit and all 48 old tests. Added 14 tests for the new study's score identities, IDs/chronology/roster purity, no-zero-imputation, integer/minute support and missing-outcome sensitivity.
- Reproducing the old study initially encountered archived repo-relative paths; resolved only an in-memory reader copy, leaving source manifests unchanged.
- Initial old-simulation score mismatch was traced to unordered equal-tipoff game assignment. Preserved the failed attempt and restored-order reproduction. Winner metric differences were about 1e-16; restored PRA scores about 7e-15.
- A partial development process was stopped by its exact verified PID, not a broad process kill, to remove repeated unused baseline calculations. Its log and compute note were retained. No final outcomes had been assessed and no completed selection receipt was replaced.
- Four development configurations were evaluated. Selected half-life 90 days, five pseudo-games, fixed season decay .65. No pooling/feature/architecture rescue was made after falsification checks.
- Original development receipts remain untouched. Two development-only diagnostics needed correction: identity-set alignment rather than list-order rejection for the 72-hour lag, and recorded-minute support for the nested individual-attempt oracle. The actual candidate's points/minutes/attempt/make arrays were verified unchanged. One diagnostic attempt stopped at a receipt-path formatting error after writing rows; it remains preserved. The successful corrected receipt is diagnostics-003. Corrected oracle and lag results are diagnostic only.
- A transparent future-period amendment extended the original November-only reservation before any future outcomes because one target per day could not satisfy the frozen minimum sample. No thresholds were reduced; original plan/registration bytes remain unchanged. No scheduled task was created.
- The final code/data/definition/development lock was written before assessment. No candidate code, selected parameter, sample rule or metric was tuned against either later assessment period.

Passing checks, extensive simulation, arithmetic agreement and explanatory plausibility do not establish predictive validity. The report retains missing local forecasts, absent point-in-time records, reused historical sources and all resulting restrictions.
