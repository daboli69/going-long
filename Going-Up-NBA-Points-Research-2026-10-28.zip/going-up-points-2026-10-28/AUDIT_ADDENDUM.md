# Audit evidence added after registration

This addendum does not rewrite the original audit, plan or prior research.

## Verified old simulator ordering defect

`scripts/king_court_diagnostics/dataset.py`, `collect_slates`, constructs games from a set and sorts only by tipoff. Simultaneous games therefore have no deterministic secondary order. A single global RNG stream assigns different draws to those games across Python hash orders.

An initial January 6, 2026 rerun differed from retained per-player PRA CRPS by as much as 0.65538 despite the same nominal seed. Restoring the retained player/game order reproduced all per-player CRPS to approximately 7.1e-15. The old winner metrics reproduced within 1.2e-16. See the two `data/original-metrics-reproduction-*.json` receipts. This is a reproducibility defect, not evidence that the saved arithmetic was wrong. The old code was left unchanged. The new study selects dates/games with explicit tie-breakers and models a single target game per origin, preserving template order in the frozen dataset.

## Raw evidence independently reproduced

- All 1,230 regular-season games passed an independent points, FGA/FGM, 3PA/3PM and FTA/FTM event-to-NBA-box reconciliation. The earlier broader event check passed 1,186 because it also checks credited assists and ambiguous names; the counts measure different things.
- The earlier event/stint audit reran to 1,186 event agreements, 1,097 stint agreements, 1,095 both, and 1,138 canonical/NBA box agreements.
- Only 1,182 games supply joint templates: 45 of the 1,230 raw games lack an accepted canonical crosswalk in this workspace, and three additional mapped games fail the conservative team-minute-total gate. The latter have aggregate player-minute totals 480.05 or 480.0667; sums at the floating three-second boundary are not repaired or substituted. These exclusions are retained equally for all comparators and are not evidence of missing injury status. No template is repaired by guessing.
- Source records are parsed NBA archives and inferred lineups/possession groups, not native vendor JSON or independent providers.

## Remaining structural limitations

The candidate jointly resamples league game templates rather than fitting opponent-specific possession dynamics. Its possession count is an explicitly reconstructed box proxy. It cannot identify causal links, a true injury/availability process, game-specific closing lineups, scoring-foul/and-one dependence, every player covariance, or unseen upper-tail support. Weighted counts with Beta/Gamma shrinkage are empirical-Bayes approximations, not a fitted full hierarchical posterior.

The prior-game roster proxy can omit newly joining players and retain unavailable/traded players. No source proves it is a current roster. Missing outcome bounds quantify score sensitivity, but cannot turn this proxy into a point-in-time forecast field. Verified rookie metadata is missing. These limitations remain even if a numerical retrospective score improves.
