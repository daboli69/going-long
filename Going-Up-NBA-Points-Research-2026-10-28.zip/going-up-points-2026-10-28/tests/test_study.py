from copy import deepcopy
from datetime import datetime, timedelta, timezone
import numpy as np
import pytest

from going_up.data import box_minutes, eligible, field, shot_credits, targets
from going_up.metrics import crps_cdf, crps_sorted, missing_outcome_bounds, paired, pmf_of
from going_up.model import allocate, cap_minutes, context, simulate, weights


def test_independent_crps_matches_pairwise_even_outside_support():
    x=np.array([0,0,2,5,10])
    for y in (0,1,7,30):
        brute=np.mean(abs(x-y))-.5*np.mean(abs(x[:,None]-x))
        assert crps_cdf(pmf_of(x),y)==pytest.approx(brute)
        assert crps_sorted(x,y)==pytest.approx(brute)


def test_no_unknown_minutes_zero_imputation():
    assert box_minutes({'minutes':'','comment':''}) is None
    assert box_minutes({'minutes':'','comment':'DNP - Coach decision'})==0
    assert box_minutes({'minutes':'12:30','comment':''})==12.5


def test_integer_allocation_no_inactive_opportunities():
    x=allocate(np.array([100,85,99]),np.array([[0,1,2],[3,0,1],[1,2,0]]),np.random.default_rng(1))
    assert np.array_equal(x.sum(axis=1),[100,85,99])
    assert x[0,0]==x[1,1]==x[2,2]==0


def test_minutes_conserve_and_keep_zero_roles():
    x=np.array([[0,100,1,1,1,1],[10,12,13,14,15,16]],float)
    result=cap_minutes(x,np.array([48,53]))
    assert np.allclose(result.sum(axis=1),[240,265])
    assert np.all(result<=np.array([48,53])[:,None]+1e-9)
    assert result[0,0]==0


def test_too_few_positive_roles_rejected():
    with pytest.raises(ValueError):cap_minutes([[1,1,1,1,0]],np.array([48]))


def test_result_embargo_and_strict_source_times():
    origin=datetime(2026,1,10,tzinfo=timezone.utc)
    row=dict(season=2026,tipoff='2026-01-08T12:00:00+00:00',known_at='2026-10-27T00:00:00+00:00')
    assert not eligible([row],origin,2026)  # exactly 36h not strictly earlier
    row['tipoff']='2026-01-08T11:59:59+00:00'
    assert len(eligible([row],origin,2026))==1
    assert not eligible([row],origin,2026,strict=True)


def test_recency_window_and_missing_seasons():
    origin=datetime(2026,1,10,tzinfo=timezone.utc)
    rows=[dict(season=s,tipoff=f'{s-1}-11-01T00:00:00+00:00') for s in (2022,2023,2024,2025,2026)]
    w=weights(rows,origin,2026,90)
    assert w[0]==0 and w[1]>0 and w[1]<w[2]<w[3]
    assert len(weights([rows[-1]],origin,2026,90))==1


def fixture():
    gs=[]
    start=datetime(2025,10,1,tzinfo=timezone.utc)
    for i in range(30):
        ps=[]
        for team in ('BOS','NYK'):
            for j in range(12):
                m=24 if j<10 else 0
                p=dict(player_id=team+str(j),name=team+str(j),team=team,position='G',minutes=m,
                       pts=8 if m else 0,reb=2 if m else 0,ast=2 if m else 0,fgm=3 if m else 0,
                       fga=8 if m else 0,tpm=1 if m else 0,tpa=3 if m else 0,ftm=1 if m else 0,
                       fta=2 if m else 0,oreb=1 if m else 0,dreb=1 if m else 0)
                ps.append(p)
        gs.append(dict(game_id='old'+str(i),season=2026,tipoff=(start+timedelta(days=i)).isoformat(),
                       known_at='2026-10-27T00:00:00+00:00',home='BOS',away='NYK',players=ps))
    target=dict(game_id='new',date='2025-11-05',season=2026,tipoff='2025-11-05T23:00:00+00:00',home='BOS',away='NYK')
    data=dict(games=gs,schedule=[target]);return data,target


def test_future_participants_cannot_change_prior_roster():
    data,target=fixture();a,_=field(data,target)
    future=deepcopy(data['games'][-1]);future['tipoff']=target['tipoff'];future['players'][0]['player_id']='UNSEEN_TARGET_STAR'
    data['games'].append(future);b,_=field(data,target)
    assert a==b and 'UNSEEN_TARGET_STAR' not in [p['player_id'] for p in a['players']]


def test_first_scheduled_game_does_not_fallback_on_missing_result():
    data,target=fixture();late=dict(target,game_id='later',tipoff='2025-11-06T01:00:00+00:00')
    data['schedule'].append(late)
    assert targets(data,'2025-11-05','2025-11-05')[0]['game_id']=='new'


def test_reconciliation_related_action_numbers_not_deduplicated():
    box=dict(person_id=1,field_goals_attempted=2,field_goals_made=1,three_pointers_attempted=1,three_pointers_made=1,free_throws_attempted=1,free_throws_made=1,points=4)
    es=[dict(order_index=1,action_number=9,person_id=1,action_type='Made Shot',shot_value=3,description='3'),
        dict(order_index=2,action_number=9,person_id=1,action_type='Missed Shot',shot_value=2,description='miss'),
        dict(order_index=3,action_number=10,person_id=1,action_type='Free Throw',shot_value=1,description='FT')]
    assert shot_credits(es,[box])['passed']
    assert shot_credits(es+[es[0]],[box])['passed']
    es.append(dict(es[0],shot_value=2))
    assert not shot_credits(es,[box])['passed']


def test_joint_candidate_accounting_reproducibility_and_tail_support():
    data,target=fixture();slate,history=field(data,target)
    par=dict(half_life=90,prior_games=5)
    pp=context(slate,history,par)
    pool=[dict(game_id=g['game_id'],season=2026,tipoff=g['tipoff'],length=48,
               home=dict(fga=80,fta=20,possession_proxy=90),away=dict(fga=90,fta=25,possession_proxy=95)) for g in history]
    a=simulate(slate,pp,pool,par,500,1);b=simulate(slate,pp,pool,par,500,1)
    assert np.array_equal(a['points'],b['points'])
    assert np.array_equal(a['points'],2*a['two_made']+3*a['three_made']+a['ft_made'])
    assert np.all(a['two_made']+a['three_made']<=a['fga']) and np.all(a['ft_made']<=a['fta'])
    for team,fg in [('BOS',80),('NYK',90)]:
        idx=[i for i,p in enumerate(pp) if p['team']==team]
        assert np.all(a['fga'][:,idx].sum(axis=1)==fg)
        assert np.allclose(a['minutes'][:,idx].sum(axis=1),240)
    assert not np.any(a['fga'][a['minutes']==0])


def test_cluster_pairs_require_same_cohort():
    a=[dict(game_id='g',player_id='p',date='2026-01-01',crps=2.)]
    b=[dict(game_id='g',player_id='p',date='2026-01-01',crps=1.)]
    assert paired(a,b,100)['game_player_95']==[-1.,-1.]
    with pytest.raises(ValueError):paired(a,[])


def test_missing_outcome_bounds_include_unbounded_integer_tail():
    forecasts=[{'players':[{'models':{'A':[1.], 'C':[0.,1.]},'observed':None}]}]
    b=missing_outcome_bounds(forecasts)
    assert b['full_proxy_field_delta_bounds']==[-1.,1.]
    assert crps_cdf([0.,1.],10000)-crps_cdf([1.],10000)==-1


def test_nested_individual_attempt_oracle_keeps_playing_time_support():
    data,target=fixture();slate,h=field(data,target);slate['observed_game_length']=48
    par=dict(half_life=90,prior_games=5);pp=context(slate,h,par)
    truth=[dict(minutes=24 if int(p['player_id'][3:])<10 else 0,
                fga=8 if int(p['player_id'][3:])<10 else 0,fta=2 if int(p['player_id'][3:])<10 else 0) for p in pp]
    pool=[dict(game_id=g['game_id'],season=2026,tipoff=g['tipoff'],length=48,
               home=dict(fga=80,fta=20,possession_proxy=90),away=dict(fga=90,fta=25,possession_proxy=95)) for g in h]
    z=simulate(slate,pp,pool,par,300,4,'observed_individual_attempts',truth)
    assert not np.any(z['fga'][z['minutes']==0])
